# Technical Design (TDD)

## Architecture and technology stack

One Django application serves the shop, the POS API, the back office and the webhooks from one 4 GB server. Slow or external work runs as background jobs, so a slow courier never blocks a customer.

&#91;embedded content: system architecture · one server, five outside services\]

| Layer | Choice | Version policy |
| --- | --- | --- |
| Language | Python 3.13 | Latest patch; move up yearly |
| Framework | Django 6.1, then 6.2 LTS once released in April 2027 (supported to April 2030) ([Django](https://www.djangoproject.com/weblog/2026/aug/10/annual-release-cycle/)) | From 2028 Django moves to yearly releases with 3 years of support each; plan one upgrade a year |
| API | Django REST Framework | Pinned |
| Shop UI | Server-rendered templates + HTMX, RTL CSS, Cairo and IBM Plex Sans Arabic fonts |  |
| POS UI | Progressive web app with IndexedDB |  |
| Database | PostgreSQL 18; adopt 19 after its first patch release (19 due 19 Nov 2026) ([PostgreSQL](https://www.postgresql.org/about/news/postgresql-19-rc-1-3409/)) | One major upgrade a year at most |
| Jobs and cache | Celery + Redis | Pinned |
| Web server | Gunicorn behind Caddy |  |
| Packaging | Docker Compose | Images built in CI |
| Edge and storage | Cloudflare (DNS, CDN, WAF), R2 | Free plan at launch |
| Monitoring | Sentry, an uptime monitor | Free tiers at launch |
| Code and CI | GitHub, GitHub Actions, Container Registry | Private repository |

## Code layout and modules

One repository, one deployable application: a modular monolith. Each Django app owns its tables and exposes a small service layer. Other apps call that layer, never each other's models directly.

```text
al-rashidi/
  apps/
    stores/        store, membership, courier account, commission rate
    catalog/       product, variant, category, image, CSV import
    search/        Arabic normalization, search index, ranking
    stock/         ledger, reservation, count, purchase receipt
    orders/        cart, order group, order, state machine, coupons
    pos/           POS sync API, drawer session, receipt
    shipping/      courier adapter (Bosta first), webhooks, settlement import
    returns/       return request, inspection, refund record
    finance/       commission, statement, invoice numbering, exports
    notify/        SMS and WhatsApp adapters, templates, outbox
    accounts/      users, roles, 2FA, store scoping
    audit/         audit log
  storefront/      server-rendered Arabic shop (templates, HTMX)
  pos-client/      POS web app (offline-capable, IndexedDB queue)
  config/          settings per environment
  deploy/          Docker Compose, Caddy, backup scripts
  docs/            this spec, ADRs, runbook
  tests/           integration and end-to-end tests
```

Conventions:

- Every model that belongs to a store has a non-null `store_id` and a store-scoped manager.
- Money is stored as integer piasters (1 EGP = 100), never as floating point.
- Times are stored in UTC and shown in Africa/Cairo.
- Every state change goes through a service function that writes the audit log.
- Integrations (courier, SMS, WhatsApp, ETA) sit behind adapter interfaces, so a second courier is a new adapter, not a rewrite.

## Data model

Every store-owned table carries `store_id`, so Order, Statement, Drawer session and Shipment all belong to one store. The stock move table (highlighted) is the only place stock changes.

&#91;embedded content: core data model · 16 tables\]

| Table | Key fields | Notes |
| --- | --- | --- |
| store | id, name\_ar, name\_en, commission\_bps, courier\_account\_ref, status | Commission in basis points (1000 = 10%) |
| variant | id, store\_id, product\_id, sku, barcode, price\_pt, cost\_pt, eta\_item\_code, reorder\_level | `_pt` = integer piasters |
| stock\_level | variant\_id, on\_hand, reserved, updated\_at | Cached totals; rebuilt from stock\_move nightly |
| stock\_move | id, store\_id, variant\_id, type, qty, ref\_type, ref\_id, user\_id, created\_at | Append-only |
| reservation | id, order\_id, variant\_id, qty, status | Released on cancel or ship |
| order\_group | id, token, customer\_id, idempotency\_key, coupon\_id, total\_pt | Unique idempotency key |
| order | id, group\_id, store\_id, state, items\_pt, delivery\_fee\_pt, discount\_pt | State history in order\_event |
| shipment | id, order\_id, courier, tracking\_no, cod\_pt, status, settled\_pt, courier\_fee\_pt, settled\_at | Filled from webhooks and settlement import |
| pos\_sale | id, store\_id, terminal\_id, client\_uuid, receipt\_no, total\_pt, drawer\_session\_id | Unique client\_uuid |
| statement | id, store\_id, month, delivered\_pt, returns\_pt, commission\_pt, status | One per store per month |
| audit\_log | id, actor\_id, store\_id, action, object, old, new, ip, created\_at | Append-only |
| outbox | id, channel, payload, status, attempts, next\_try\_at | Messages and outbound calls |

## Order state machine

Each store's order moves through these states. Any other move is refused (FR-ORD-01), and every move is logged with who and when.

&#91;embedded content: order state machine · 10 states\]

| From | To | Trigger | Stock effect |
| --- | --- | --- | --- |
| Placed | Confirmed | Phone code verified | Reserve stock |
| Placed | (deleted) | No code within 30 minutes | None |
| Confirmed or Packed | Cancelled | Customer, store or admin cancels before handover | Release reservation |
| Confirmed | Packed | Store marks packed; courier label created | None |
| Packed | With courier | Courier pickup scan (webhook) | Reservation converts to a `ship_online` stock move |
| With courier | Delivered | Courier delivered and cash collected | None; commission accrues |
| With courier | Delivery failed | Courier reports refused or unreachable | None |
| Delivery failed | With courier | Courier retries (as set in the courier account) | None |
| Delivery failed | Returned to store | Parcel back and inspected | `return_restock` or `write_off` |
| Delivered | Return requested | Customer within the return window | None |
| Return requested | Return received | Courier return pickup arrives; store inspects | `return_restock` or `write_off` |
| Return received | Refunded | Refund recorded | Statement adjusted |

The order group has no state of its own. Its status is derived from its orders, for example "1 of 2 delivered".

## Stock ledger and concurrency

**Stock is never edited in place. Every change is a ledger row, and on-hand stock is a cached sum checked nightly against the ledger.** This makes overselling impossible by construction and every number auditable.

| Movement type | Sign | Created by |
| --- | --- | --- |
| `receipt` | + | Purchase receipt from a supplier |
| `sale_pos` | - | POS sale (on sync) |
| `ship_online` | - | Order handed to the courier |
| `return_restock` | + | Return inspected as sellable |
| `write_off` | - | Damaged, lost or expired |
| `count_adjust` | +/- | Approved count difference |

Reservations are kept apart from the ledger: `available = on_hand - reserved`.

The last-unit rule (FR-STK-03), in one database transaction:

1. Lock the SKU's stock row (`SELECT ... FOR UPDATE`).
2. Re-read `on_hand` and `reserved`.
3. If available is less than the quantity, abort with "out of stock".
4. Insert the reservation or ledger row and update the cached totals.
5. Commit.

Locks are taken in SKU order to avoid deadlocks. Each request locks only its own SKUs, which is light at this scale.

**When an offline POS sale meets an empty shelf:** the sale still syncs, because the goods physically left the store. If it pushes stock below zero, the system flags a *negative stock event* for the manager. It also cancels the newest unshipped online reservation for that SKU, and the customer is told; nothing needs refunding because no cash was collected yet. This is the one case where the counter beats the website, and it is logged.

## API design and integrations

The storefront is rendered on the server; the POS and integrations use a versioned JSON API under `/api/v1/`, built with Django REST Framework.

| Endpoint | Caller | Purpose |
| --- | --- | --- |
| `POST /api/v1/checkout/otp` | Shop | Send a phone code (rate-limited) |
| `POST /api/v1/checkout/place` | Shop | Place an order group; requires an `Idempotency-Key` header |
| `GET /api/v1/track/{token}` | Shop | Order group status by private token |
| `GET /api/v1/pos/catalog?since=` | POS | Changed products and stock since a timestamp |
| `POST /api/v1/pos/sales:batch` | POS | Upload queued sales; each carries a client UUID, so re-sends are ignored |
| `POST /api/v1/pos/drawer/{id}/close` | POS | Close a drawer session with the count |
| `POST /hooks/courier/bosta` | Courier | Status webhook; secret checked in constant time; event stored before processing |
| `GET /api/v1/stores/{id}/statement/{yyyy-mm}` | Back office | Statement data and export |

**Rules for every integration:**

- Outbound calls go through a job queue with retries and exponential backoff. Failures land on a visible "needs attention" list.
- Inbound webhooks are stored raw first, then processed by a job, so nothing is lost if processing fails.
- An outbox table records every message to send. A job sends it, so a crash cannot send a message twice or lose it.
- Each store's courier API key is stored encrypted. It is used only for that store's shipments.
- The courier adapter maps courier states to platform states in one table, with unknown states flagged and never guessed.

**Courier (Bosta first):** create a delivery with type *send* and the COD amount, print the airway bill, track, and book customer-return pickups. Bosta's API also offers cash-collection and exchange delivery types ([ShipBridge driver docs](https://packagist.org/packages/mohamedhekal/shipbridge-bosta)). Settlement data (COD amount, fees, deposit date) is imported per shipment for matching ([Laravel Bosta package](https://root.packagist.org/packages/shippulse/laravel-bosta)). Confirm every endpoint against Bosta's official documentation with a staging key.

**ETA (later):** receipts must carry ETA item codes (GS1 or EGS). Each outlet registers as its own POS. Offline receipts must reach ETA within 24 hours ([e-receipt guide](https://invoicedataextraction.com/blog/egypt-electronic-receipt-compliance-guide)). The data model keeps an `eta_item_code` on every variant from day one, so this can be switched on per store.

## POS offline design and Arabic search

**POS:** a web app installed on the tablet's home screen (a progressive web app). It caches the store's catalog and stock in the browser's IndexedDB, refreshed every 5 minutes from `/pos/catalog?since=`.

1. A sale is written locally first, with a client UUID and a local receipt number such as `S03-T02-000154` (store, terminal, sequence).
2. A background sync uploads queued sales in order. The server ignores any UUID it has already seen.
3. The screen shows a visible "offline, N sales waiting" badge. After 60 minutes offline it warns the cashier.
4. Prices and stock on the tablet may be up to 5 minutes old; the server's ledger is always the truth.

Test the exact tablet, browser, scanner and printer in the proof. Receipt printing from a browser is the most common practical snag.

**Arabic search:** PostgreSQL full-text search plus trigram similarity (`pg_trgm`), on a normalized copy of each product's names.

| Step | Example |
| --- | --- |
| Remove diacritics and tatweel | كُرَّاسة → كراسة |
| Unify hamza forms to bare alif | أقلام → اقلام |
| Ta marbuta to ha | كراسة → كراسه |
| Alif maqsura to ya | مستشفى → مستشفي |
| Arabic digits to Latin | ١٢ → 12 |
| Lower-case Latin, trim spaces | Faber Castell → faber castell |

The same function normalizes the stored text and the query. A synonyms table (for example شنطة / حقيبة) is maintained by the admin from real no-result searches. At 3,000 to 30,000 products this needs no separate search server. Meilisearch or OpenSearch is a later option only if measurements demand it.

## Security, privacy and audit

| Area | Design |
| --- | --- |
| Store isolation | Store-scoped managers on every store model; a request middleware sets the user's store; a test runs every API and admin view as a user of another store and expects "not found" |
| Authentication | Django auth; two-factor (TOTP) for managers and admins; customers verify by phone OTP only |
| Sessions | Secure, HttpOnly, SameSite cookies; 12-hour POS sessions; 30-minute idle timeout in the back office |
| Passwords | Argon2 hashing; 10-character minimum; lockout after repeated failures |
| Edge | Cloudflare WAF and rate limits on login, OTP, checkout and webhooks; admin path restricted by Cloudflare Access or IP |
| Secrets | Environment files outside the repository; courier keys encrypted in the database; rotated when staff leave |
| Dependencies | Pinned versions; Dependabot and `pip-audit` in CI; monthly patch window |
| Data | Card data never touches the platform; customer phone and address shown to store staff only for their own orders |
| Audit | Append-only audit table: actor, store, action, object, old value, new value, time, IP |
| Backups | Encrypted before upload; restore tested monthly |
| Checklist | OWASP ASVS level 1 before launch |

## Environments, deployment, backups and observability

| Environment | Where | Data | Purpose |
| --- | --- | --- | --- |
| Local | Developer laptop, Docker Compose | Generated test data | Build and unit tests |
| Staging | Same server as production, separate containers and database (MVP); its own small server later | Copy of production with personal data masked | Proof tests, acceptance, courier staging keys |
| Production | 4 GB VPS behind Cloudflare; location decided by the PDPL review | Real | Live shop and POS |

**Deployment:** GitHub Actions runs lint, type checks and tests on every push. A tagged release builds one Docker image and pushes it to the GitHub Container Registry. The server pulls it, runs migrations, and switches over. A smoke test then checks shop, login, POS sync and webhook health. The last two images are kept for a rollback in under 5 minutes. Migrations must be backward compatible for one release, so a rollback never needs a database restore.

**Backups:**

- nightly `pg_dump` plus media, encrypted and copied to Cloudflare R2 (a different provider from the server), kept 30 days
- a weekly copy kept offline
- in P1, continuous WAL archiving (for example with pgBackRest or WAL-G) for about 1-hour recovery

**Observability:**

- Sentry for errors
- an uptime monitor on the shop, login and the webhook endpoint
- a daily check that last night's backup exists
- alerts when the job queue or the "needs attention" list grows past a threshold
- structured logs with a request ID
- a nightly stock-ledger consistency check that alerts on any mismatch

## Appendix: if WooCommerce + Dokan + wePOS wins the proof

The PRD, SRS, Test plan and Ops runbook stay valid. This TDD changes as follows:

| Topic | Django design | WooCommerce path |
| --- | --- | --- |
| Stores | `store_id` on every row | Dokan vendors |
| Catalog, cart, checkout | Custom apps | WooCommerce core, Dokan multi-vendor cart (one sub-order per vendor) |
| POS | Custom offline web app | wePOS per vendor ([Dokan](https://dokan.co/?p=512636)); offline behaviour must pass the proof |
| Stock and last-unit rule | Ledger with row locks | WooCommerce stock; the concurrency test (FR-STK-03) decides if it is safe |
| Arabic search | PostgreSQL normalization | A search plugin plus a small custom normalization filter |
| Courier | Custom adapter | Bosta's WooCommerce plugin or a small custom plugin; verify per-vendor API keys |
| Statements | Custom finance app | Dokan commission reports plus a custom statement export |
| Database | PostgreSQL | MySQL or MariaDB |
| Custom code | Django apps | One site plugin with all customizations; no theme or core edits |
| Upkeep | Python dependencies | WordPress, WooCommerce and plugin updates weekly on staging first |

The extra watch items on this path are plugin licence renewals, plugin compatibility after updates, and WordPress security hardening.
