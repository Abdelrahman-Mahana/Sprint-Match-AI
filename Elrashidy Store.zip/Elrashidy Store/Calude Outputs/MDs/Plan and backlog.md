# Project Plan and Backlog

## Phases and gates

At 20 hours a week from 16 November 2026, public launch lands in early July 2027. That leaves about two months of live running before the September back-to-school peak. Each phase ends at a gate; the next phase does not start until it passes.

&#91;embedded content: delivery timeline · 10 phases, 1 launch date\]

| Gate | Passes when |
| --- | --- |
| End of 0 Decide | Partnership terms signed; lawyer and accountant answers booked; courier staging keys in hand |
| End of 1 Prove | All proof tests recorded; ADR-001 accepted or superseded |
| End of each build phase | Its requirements' acceptance criteria shown on staging |
| End of 8 Hardening | Every Must test passes; restore drill passed; security checklist done |
| End of 9 Pilot | A real order, return and monthly statement succeed; zero oversold orders; cost under ceiling |

If WooCommerce wins the proof, phases 2 to 8 shrink to about 6 to 11 weeks, and launch can move to spring 2027.

## Task backlog

The Django build is about 506 hours (phases 2 to 8), near the top of the 350 to 550 estimate. All 48 tasks come to 639 hours. Each task traces to a requirement, so nothing is built without a reason. Update the Status column as work moves.

| ID | Task | Phase | Est. h | Owner | Traces to | Status |
| --- | --- | --- | --- | --- | --- | --- |
| T-01 | Sign the partnership agreement: pay or share, running costs, code ownership, exit | 0 Decide | 4 | Owner, PM | - | Not started |
| T-02 | Draft the store contract: commission, returns, failed-delivery fees | 0 Decide | 6 | PM, lawyer | BR-05, BR-08, BR-10 | Not started |
| T-03 | Lawyer: PDPL licence and hosting location, return wording, central courier account question | 0 Decide | 4 | PM | NFR-PRIV-01 | Not started |
| T-04 | Accountant: ETA status per store; is the platform VAT-registered | 0 Decide | 3 | PM | - | Not started |
| T-05 | Courier business accounts and staging API keys (Bosta and one alternative) | 0 Decide | 3 | PM | FR-SHP-01 | Not started |
| T-06 | SMS and WhatsApp quotes; sender name registration | 0 Decide | 3 | PM | FR-NTF-01 | Not started |
| T-07 | Brand token file: one palette, one font set, corrected logo | 0 Decide | 6 | Designer | NFR-L10N-01 | Not started |
| T-08 | 3,000-product test file for 2 stores | 1 Prove | 6 | Store owner, dev | FR-CAT-03 | Not started |
| T-09 | Django spike: run proof tests 1 to 11 | 1 Prove | 40 | Dev | Test plan | Not started |
| T-10 | WooCommerce + Dokan + wePOS spike: run proof tests 1 to 11 | 1 Prove | 24 | Dev | Test plan | Not started |
| T-11 | Final decision record for ADR-001 | 1 Prove | 2 | PM | ADR-001 | Not started |
| T-12 | Repository, CI, Docker Compose, environments | 2 Foundation | 16 | Dev | NFR-MNT-01 | Not started |
| T-13 | Server hardening, Cloudflare, Caddy, TLS | 2 Foundation | 10 | Dev | NFR-SEC-01 | Not started |
| T-14 | Backups to R2 and the first restore drill | 2 Foundation | 8 | Dev | NFR-REC-01 | Not started |
| T-15 | Accounts, roles, 2FA, store scoping and the isolation test | 2 Foundation | 24 | Dev | FR-SEC-01, FR-SEC-02 | Not started |
| T-16 | Audit log and outbox | 2 Foundation | 10 | Dev | NFR-AUD-01 | Not started |
| T-17 | Store, product, variant and category models with admin screens | 3 Catalog | 20 | Dev | FR-CAT-01, FR-CAT-02 | Not started |
| T-18 | CSV import with row error report | 3 Catalog | 16 | Dev | FR-CAT-03 | Not started |
| T-19 | Images to R2 with WebP resizing | 3 Catalog | 8 | Dev | FR-CAT-04 | Not started |
| T-20 | Arabic normalization, search and filters | 3 Catalog | 24 | Dev | FR-SRC-01 to 03 | Not started |
| T-21 | Storefront RTL theme: home, category, product, search | 3 Catalog | 40 | Dev, designer | NFR-PERF-01, NFR-L10N-01 | Not started |
| T-22 | Cart split per store and zone delivery fees | 4 Orders | 20 | Dev | FR-CHK-03, FR-CHK-04 | Not started |
| T-23 | Guest checkout, phone OTP, idempotent placement | 4 Orders | 16 | Dev | FR-CHK-01, 02, 06 | Not started |
| T-24 | Coupons | 4 Orders | 8 | Dev | FR-CHK-05 | Not started |
| T-25 | Order state machine, tracking link, cancellation | 4 Orders | 16 | Dev | FR-ORD-01 to 03 | Not started |
| T-26 | Pick list and pack slip | 4 Orders | 6 | Dev | FR-ORD-04 | Not started |
| T-27 | Stock ledger, reservations, last-unit locking | 5 Stock and POS | 20 | Dev | FR-STK-01 to 03 | Not started |
| T-28 | Counts, purchase receipts, low-stock alerts | 5 Stock and POS | 16 | Dev | FR-STK-04 to 06 | Not started |
| T-29 | POS web app: scan, sell, receipt | 5 Stock and POS | 32 | Dev | FR-POS-01, FR-POS-03 | Not started |
| T-30 | POS offline queue and sync | 5 Stock and POS | 20 | Dev | FR-POS-02 | Not started |
| T-31 | Counter refunds, drawer sessions, cashier logins | 5 Stock and POS | 16 | Dev | FR-POS-04 to 06 | Not started |
| T-32 | Courier adapter: shipment, label, tracking | 6 Courier | 16 | Dev | FR-SHP-01 | Not started |
| T-33 | Courier webhooks and polling for stuck shipments | 6 Courier | 12 | Dev | FR-SHP-02, FR-SHP-03 | Not started |
| T-34 | Settlement import and matching | 6 Courier | 12 | Dev | FR-SHP-04 | Not started |
| T-35 | Returns flow | 6 Courier | 14 | Dev | FR-RET-01 to 03 | Not started |
| T-36 | Order messages by SMS or WhatsApp; marketing consent | 6 Courier | 12 | Dev | FR-NTF-01, FR-NTF-02 | Not started |
| T-37 | Commission and monthly statement with exports | 7 Finance | 20 | Dev | FR-FIN-01, FR-FIN-02 | Not started |
| T-38 | Statement accept or dispute; invoice numbering | 7 Finance | 10 | Dev | FR-FIN-03, FR-FIN-04 | Not started |
| T-39 | Reports: daily sales, stock valuation, low stock | 7 Finance | 12 | Dev | FR-RPT-01 | Not started |
| T-40 | Admin: invite, activate and suspend stores | 7 Finance | 8 | Dev | FR-ADM-01, FR-ADM-02 | Not started |
| T-41 | Load test and performance fixes | 8 Hardening | 12 | Dev | NFR-PERF-01, 02 | Not started |
| T-42 | Security checklist (ASVS L1) and permission matrix test | 8 Hardening | 12 | Dev | NFR-SEC-01 | Not started |
| T-43 | Accessibility and Arabic UX review on real phones | 8 Hardening | 8 | Designer, PM | NFR-A11Y-01 | Not started |
| T-44 | Training notes in Arabic for each role | 8 Hardening | 8 | PM | - | Not started |
| T-45 | Restore drill and runbook dry run | 8 Hardening | 4 | Dev | NFR-REC-01 | Not started |
| T-46 | Import the real catalog for Al-Rashidi and store 2 | 9 Pilot | 8 | Stores, dev | FR-CAT-03 | Not started |
| T-47 | Four-week pilot with daily review | 9 Pilot | 20 | PM, stores | Launch gates | Not started |
| T-48 | First monthly statement for both stores | 9 Pilot | 4 | PM, accountant | FR-FIN-02 | Not started |

To stay within 350 hours, cut first: T-24 coupons, T-28 purchase receipts (keep counts), T-39 reports beyond daily sales, and T-21 pages beyond category and product.

## Roles, responsibilities and cadence

| Role | Responsible for | Decides |
| --- | --- | --- |
| PM (you) | Scope, backlog order, gates, risks, vendor and legal follow-up | What is in each release; whether a gate passes |
| Developer (your friend) | Design, code, tests, deployment, runbook | How it is built, within the ADRs |
| Owner and partners | Funding, store relationships, commission policy | Business rules marked *to confirm* |
| Store managers | Product data, stock counts, packing, POS use | Their prices and stock |
| Accountant | Statement format, tax questions, monthly reconciliation | Accounting treatment |
| Lawyer | PDPL, consumer law, contracts | Legal wording and licences |

**Working cadence:**

- **Two-week sprints.** Plan on day 1 from the backlog. Demo on staging on the last day, with the owner watching a real flow, not slides.
- **Weekly 30-minute check:** progress against the backlog, blockers, the top 3 risks, and any decision needed.
- **Definition of done for a task:**
  - code reviewed
  - tests pass in CI
  - linked requirement's acceptance criteria shown on staging
  - runbook updated if operations changed
- **Change control:** a new idea goes to the backlog with a requirement ID. It enters a sprint only if something of equal size leaves.
- **Monthly:** restore drill, cost review, watch-list review (Risks tab).
