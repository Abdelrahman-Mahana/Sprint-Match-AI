# Risks, Watch List and Future Plan

## Risk register

The two highest risks are commercial and legal, not technical: order volume, and hosting customer data outside Egypt.

| ID | Risk | Likelihood | Impact | Mitigation | Owner |
| --- | --- | --- | --- | --- | --- |
| R-01 | Order volume never covers build time and running costs | High | High | Pilot with 2 stores first; minimum monthly fee or cost cover in partnership terms; review at month 6 | Owner |
| R-02 | Hosting abroad breaks the PDPL cross-border rules | High | High | Lawyer decides before launch: licence, or a host in Egypt; architecture is portable (Docker) | PM |
| R-03 | Stack switched again mid-build | Medium | High | ADRs with reopen triggers; no change without a failed test | PM |
| R-04 | Ownership or payment dispute between partners | Medium | High | Signed agreement before T-12 | Owner |
| R-05 | Overselling between POS and online | Medium | Medium | Ledger with row locks; AT-03 on every push | Developer |
| R-06 | Courier API changes or outage | Medium | Medium | Adapter, raw webhook store, hourly polling, second courier in P1 | Developer |
| R-07 | Settlement does not match orders | Medium | High | Weekly matching; disputes logged with the courier | PM |
| R-08 | A store is named in an ETA e-receipt decision | Medium | High | Each store checks its status now; keep a certified POS for that store until P2 | Accountant |
| R-09 | Server price or availability changes | High | Medium | Monthly cost review; portable Docker setup; backups off-provider | Developer |
| R-10 | Single developer unavailable | Medium | High | Docs, runbook and ADRs current; code in a shared repository the owner controls | PM |
| R-11 | Browser receipt printing fails on store hardware | Medium | Medium | Test exact printer in the proof; a small local print helper as fallback | Developer |
| R-12 | Return abuse or disputes | Medium | Medium | Inspection step; photo evidence; clear return policy at checkout | Stores |
| R-13 | Spam orders or OTP abuse | Medium | Medium | Rate limits, Cloudflare, OTP lockout, blocklist of phones | Developer |
| R-14 | Brand errors reach print | Medium | Medium | One approved token file and logo set | Designer |

## Watch list

These facts change on their own schedule. Re-check each one on its cadence and before any decision that depends on it.

| Item | Current position (checked 9 to 10 Nov 2026) | Why it matters | Check |
| --- | --- | --- | --- |
| PDPL licences and cross-border transfer | Regulations in force since Nov 2025; grace period ended 1 Nov 2026; transfers abroad need a licence ([Al Tamimi](https://www.tamimi.com/news/from-policy-to-practice-egypt-issues-executive-regulations-of-the-personal-data-protection-law), [Mondaq](https://www.mondaq.com/privacy-protection/1731130/the-issuance-of-the-executive-regulations-of-the-data-protection-law-and-the-establishment-of-the-data-protection-centre)) | Hosting location, marketing messages, breach duties | Monthly until settled, then quarterly |
| ETA e-receipt decisions | Scope is per named taxpayer, by decision ([guide](https://invoicedataextraction.com/blog/egypt-electronic-receipt-compliance-guide)) | Any store named must issue e-receipts | Quarterly, and on any ETA announcement |
| Hetzner prices and plan availability | Cheap CX plans marked unavailable in Sept 2026 ([Schmalbach](https://www.vincentschmalbach.com/hetzner-cheap-cloud-unavailable-price-increases/)) | 30 USD ceiling | Before ordering; monthly |
| WhatsApp per-message prices for Egypt | Per-message billing since July 2025; Egypt utility about 0.0036 USD plus 14% VAT, with changes from 1 Oct 2026 ([ChatMaxima summary](https://chatmaxima.com/whatsapp-api-pricing/egypt/); verify on [Meta](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing)) | Message costs | Quarterly |
| Courier tariffs and API | Bosta tariffs by zone; API via staging keys | Delivery fees, integration | Quarterly; on any API notice |
| Django release policy | 6.1 now; 6.2 LTS April 2027 to April 2030; yearly releases from 2028 ([Django](https://www.djangoproject.com/weblog/2026/aug/10/annual-release-cycle/)) | Upgrade planning | Each release |
| PostgreSQL versions | 18 current; 19 due 19 Nov 2026; 14 reaches end of life 12 Nov 2026 ([PostgreSQL](https://www.postgresql.org/about/news/postgresql-19-rc-1-3409/)) | Upgrade planning | Each quarterly patch release |
| Consumer protection rules | 14-day return, 30 days if defective, under Law 181/2018 ([Al-Ahram](https://english.ahram.org.eg/NewsContent/50/0/409645/AlAhram-Weekly/0/INTERVIEW-Safeguarding-consumer-rights-in-Egypt.aspx)) | Return policy | Yearly, or on amendments |
| CBE payment rules | Licensing rules for payment providers issued June 2025 ([Business Today Egypt](https://www.businesstodayegypt.com/amp/1/6465/Central-Bank-of-Egypt-issues-new-licensing-rules-for-payment)) | Before cards or wallets in P1 | Before P1 |
| Free tiers (Cloudflare, R2, Sentry) | Free at current usage | Cost ceiling | Monthly |
| Security advisories | Django, PostgreSQL, Python packages | Patching | Weekly via Dependabot |

## Pro tips and future plan

**Pro tips for the build:**

1. **Write the proof tests as code first.** AT-03 (last unit) and AT-10 (statement) become permanent CI tests, so correctness never drifts.
2. **Keep the ETA item code field from day one.** Switching on e-receipts later is then a configuration task, not a migration.
3. **Store courier webhooks raw before processing.** Most courier bugs are fixed by replaying stored events.
4. **Never edit money or stock; add a correcting entry.** Auditors and store owners trust a trail they can follow.
5. **Launch before the season, not in it.** The September back-to-school peak is the wrong time for first bugs. Aim to be live by early July 2027.
6. **Measure Arabic search with real queries every month.** Add synonyms from the no-result log; it is the cheapest conversion win.
7. **Use an AI coding assistant for scaffolding and tests, not for money rules.** The accountant and the PM sign off commission and statement logic, and the assistant never sees production data.
8. **Keep the owner in control of the accounts:** the GitHub organization, domain, Cloudflare and server accounts belong to the business, with the developer as a member.
9. **Photograph products in one consistent setup from day one.** Good images matter more than any feature for conversion.
10. **Budget a small monthly marketing test** (about 1,000 EGP, *to confirm*) per store. A platform with no traffic proves nothing about the software.

**Future plan:**

| When | Item | Gate before starting |
| --- | --- | --- |
| P1 (about 3 months after launch) | Card payments through a licensed gateway such as Paymob; customer accounts and saved addresses; second courier; owner daily summary; continuous WAL backups | Pilot metrics met; CBE and PDPL answers in hand |
| P1 | Read-only AI assistant for owners ("what sold best this week?") through a read-only API user | No personal data leaves Egypt without a licence |
| P2 (6 to 12 months) | Open seller sign-up with identity checks; e-receipts for named stores; reorder suggestions from 3+ months of sales; loyalty points | 10 stores active and profitable on average |
| P2 | Shared master catalog (one product, many stores' offers) | Duplicate products become a real problem |
| Later | Native app only if the web app hits real limits; same-day local delivery; B2B sales to schools | Customer demand shown in data |

## Sources

Checked 9 to 10 November 2026. Vendor and blog pages are leads; confirm each fact at the source before relying on it.

- [PM Evaluation and Tool Selection (this project)](https://claude.ai/artifact/KAsg1jd4uSU4yiX66tkMME)
- [Django: annual release cycle and support dates](https://www.djangoproject.com/weblog/2026/aug/10/annual-release-cycle/)
- [PostgreSQL 19 RC 1 and release schedule](https://www.postgresql.org/about/news/postgresql-19-rc-1-3409/)
- [Al Tamimi: Egypt PDPL executive regulations](https://www.tamimi.com/news/from-policy-to-practice-egypt-issues-executive-regulations-of-the-personal-data-protection-law)
- [Soliman Hashish (Mondaq): PDPL compliance deadline](https://www.mondaq.com/privacy-protection/1731130/the-issuance-of-the-executive-regulations-of-the-data-protection-law-and-the-establishment-of-the-data-protection-centre)
- [Al-Ahram: consumer rights under Law 181/2018](https://english.ahram.org.eg/NewsContent/50/0/409645/AlAhram-Weekly/0/INTERVIEW-Safeguarding-consumer-rights-in-Egypt.aspx)
- [Egypt e-receipt compliance guide, Aug 2026](https://invoicedataextraction.com/blog/egypt-electronic-receipt-compliance-guide)
- [Thomson Reuters: e-invoicing in Egypt](https://europe.thomsonreuters.com/news/e-invoicing-in-egypt/)
- [Business Today Egypt: CBE payment licensing rules](https://www.businesstodayegypt.com/amp/1/6465/Central-Bank-of-Egypt-issues-new-licensing-rules-for-payment)
- [Meta: WhatsApp Business Platform pricing](https://developers.facebook.com/documentation/business-messaging/whatsapp/pricing)
- [ChatMaxima: WhatsApp API pricing in Egypt](https://chatmaxima.com/whatsapp-api-pricing/egypt/)
- [Schmalbach: Hetzner cheap cloud tier unavailable](https://www.vincentschmalbach.com/hetzner-cheap-cloud-unavailable-price-increases/)
- [Bosta Python SDK](https://pypi.org/project/bostaSDK)
- [Bosta Node.js SDK](https://github.com/bostaapp/bosta-nodejs)
- [ShipBridge Bosta driver](https://packagist.org/packages/mohamedhekal/shipbridge-bosta)
- [Laravel Bosta package](https://root.packagist.org/packages/shippulse/laravel-bosta)
- [Dokan: wePOS supports Dokan](https://dokan.co/?p=512636)
