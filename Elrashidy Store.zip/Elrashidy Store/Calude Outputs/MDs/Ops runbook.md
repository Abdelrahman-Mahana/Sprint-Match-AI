# Operations Runbook

## Routines

| When | Who | Routine |
| --- | --- | --- |
| Daily, morning | Developer or PM | Check uptime, Sentry errors, last night's backup, the "needs attention" list, stuck shipments |
| Daily, closing | Each store | Close POS drawers; pack and hand over orders; check that today's POS sales synced |
| Weekly | Store managers | Cycle-count about 10% of products; review returns and failed deliveries |
| Weekly | PM | Match the courier's weekly settlement report to delivered orders; review the backlog and risks |
| Weekly | Developer | Apply security patches on staging, then production |
| Monthly, 1st | Platform admin | Build and send statements; issue commission invoices |
| Monthly | Developer | Restore drill on a clean server; dependency and secrets review |
| Monthly | PM | Cost review against the 30 USD ceiling; watch-list review |
| Quarterly | PM, owner | Review commission, delivery fees and store performance; plan the next release |
| Yearly | Developer | Django and PostgreSQL major upgrade window |

## Deploy, rollback, backup and restore

**Deploy (tagged release):**

1. Tag the release in GitHub; CI builds and pushes the image.
2. On the server: `docker compose pull`, then `docker compose run --rm web python manage.py migrate`.
3. `docker compose up -d`; run the smoke test script.
4. Watch Sentry and the queue for 30 minutes.

**Rollback:**

1. Set the previous image tag in the env file.
2. `docker compose up -d`.
3. Migrations are backward compatible for one release, so there is no database restore.

**Nightly backup (cron at 02:15 Cairo time):**

```bash
set -euo pipefail
STAMP=$(date +%F)
cd /backups
docker compose -f /srv/app/compose.yml exec -T db pg_dump -U app -Fc alrashidi > db-$STAMP.dump
tar -czf media-$STAMP.tgz /srv/media
for f in db-$STAMP.dump media-$STAMP.tgz; do
  age -r "$BACKUP_PUBLIC_KEY" -o "$f.age" "$f" && rm "$f"
done
rclone copy /backups r2:alrashidi-backups/$STAMP --include "*-$STAMP.*.age"
rclone delete r2:alrashidi-backups --min-age 30d
find /backups -name "*.age" -mtime +3 -delete
```

The backup encryption key's private half is kept offline by the owner, never on the server.

**Monthly restore drill:**

1. Start a clean server from the repository.
2. Download last night's files and decrypt them.
3. Run `pg_restore` into an empty database, then start the stack.
4. Log in; check yesterday's orders, one statement and one stock level.
5. Record the time taken in the drill log. The target is under 4 hours.

## Incident playbooks

| Incident | First 15 minutes | Then |
| --- | --- | --- |
| Shop down | Check the uptime alert, Cloudflare status, server, then containers; restart the failed container | If the server is lost: rebuild from the repository, restore the latest backup; post a notice on WhatsApp |
| POS cannot sync | Confirm the store's internet; POS keeps selling offline | After 60 minutes offline, the store counts sales on paper as a fallback; sync and reconcile when back |
| Courier webhooks stop | Check the webhook log and the courier dashboard | Hourly polling catches up (FR-SHP-03); contact courier support |
| Settlement mismatch | Freeze the affected statement | Compare courier lines to orders; raise a ticket with the courier; correct with an adjustment entry, never an edit |
| Negative stock event | Manager checks the shelf | Recount; cancel or delay the affected online order and call the customer |
| Suspected breach | Disable affected accounts and keys; rotate secrets | Preserve logs; tell the lawyer at once. PDPL requires notifying the data protection centre within 72 hours ([Al Tamimi](https://www.tamimi.com/news/from-policy-to-practice-egypt-issues-executive-regulations-of-the-personal-data-protection-law)) |
| Messages failing | Check the provider status and balance | Switch to the backup channel (SMS or WhatsApp); retry from the outbox |
| Bad release | Roll back to the previous image | Write a short post-mortem: what happened, why, what changes |

After every incident, write a five-line note in the incident log: date, impact, cause, fix, prevention.
