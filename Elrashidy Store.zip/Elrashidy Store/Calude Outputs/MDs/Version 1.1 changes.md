# Version 1.1 changes, 15 November 2026

The PM confirmed four decisions on 15 November 2026. This tab lists every change they cause. The other tabs still read as version 1.0; where they differ from this tab, this tab is right. The Arabic document has not been updated.

## What was decided

| # | Decision | Recorded as |
| --- | --- | --- |
| 1 | "Like Amazon" means an Amazon-style shopping experience for 2 to 10 invited stores. Open seller sign-up stays in P2. | Overview, decisions table |
| 2 | Commit to Django + PostgreSQL now. The two-week WooCommerce comparison is dropped. | ADR-014; ADR-001 becomes Accepted |
| 3 | The storefront stays server-rendered and gains page transitions and small interactive parts. | ADR-015, supersedes ADR-005 |
| 4 | Styling is one design-token file and plain CSS, with self-hosted fonts and scripts and no build step. | ADR-016 |

## New decision records

| ADR | Decision | Why | Trade-off | Status | Reopen when |
| --- | --- | --- | --- | --- | --- |
| 014 | Commit to Django + PostgreSQL now; drop the two-week WooCommerce comparison | The goal is a custom storefront, which WooCommerce would constrain; saves about 50 hours | No second opinion from a rival stack; tests AT-01 to AT-11 stay as must-pass acceptance tests | Accepted | A must-pass acceptance test cannot be met within its phase |
| 015 | Server-rendered storefront with HTMX, cross-document view transitions and small interactive parts; not a single-page app | Keeps the speed of server rendering and adds app-like movement; one codebase; fits the 4 GB server | Transitions are an enhancement: a browser without them loads pages normally | Accepted | The speed or motion targets cannot be met this way, or a native app is required (P2) |
| 016 | One design-token file; plain modern CSS; fonts and scripts self-hosted; no CSS framework and no front-end build step at MVP | Nothing to compile or keep patched; small pages; no third-party requests | Less ready-made UI; components are written by hand | Accepted | The stylesheet passes its 30 KB budget or component work slows delivery |

## Requirements

| ID | Change |
| --- | --- |
| NFR-PERF-01 | Rewritten from "usable in under 3 s" to three measured targets on a mid-range Android phone over 4G: largest content visible in 2.5 s or less, tap response in 200 ms or less, layout shift 0.1 or less. The server target (500 ms at the 95th percentile) is unchanged. |
| NFR-PERF-03 | New. Page-weight budget for a first visit: scripts 50 KB, styles 30 KB, fonts 160 KB (compressed), main picture 150 KB. No third-party scripts on shop pages. |
| NFR-UX-01 | New. Motion rules: transform and opacity only, 320 ms at most, never delays a tap, off under reduced motion, nothing animates on its own. |
| FR-UX-01 | New, Must. Page-to-page transitions; the product picture travels from its card to its product page. |
| FR-UX-02 | New, Must. Add to cart in place; cart drawer grouped per store with each store's delivery fee. |
| FR-UX-03 | New, Should. Search suggestions while typing. Moved forward from P1; the PM should confirm. |
| FR-UX-04 | New, Should. Swipe and zoom in the photo gallery. |
| FR-UX-05 | New, Must. A loading, empty and error state for every screen. |

Totals: 57 functional requirements (51 Must), up from 52 (48 Must); 15 non-functional, up from 13.

Proposed for P1, not in the MVP: ratings and reviews, wishlist, recently viewed, more from this store.

## Tests

| ID | Change |
| --- | --- |
| AT-05 | Now measures the three NFR-PERF-01 targets and the page-weight budget, on home as well as category and product. |
| AT-21 | New. Browse and check out normally, with reduced motion, and with scripts off. All three must complete an order. |
| AT-01 to AT-11 | No longer a two-stack proof. They remain must-pass acceptance tests for the Django build. |

## Plan and hours

| Task | Before | After | Why |
| --- | --- | --- | --- |
| T-09 | 40 h, Django spike of all proof tests | 16 h, risk slice: last-unit locking, POS offline and printing on real hardware | No second stack to compare; the hardware risks are still worth proving early |
| T-10 | 24 h, WooCommerce spike | Dropped | ADR-014 |
| T-11 | 2 h, final decision record | Done | Recorded as ADR-014 |
| T-21 | 40 h | 56 h | Page transitions and motion rules across the theme |
| T-43 | 8 h | 12 h | Adds speed and motion checks on real phones |
| T-49 | - | 16 h, new | Design system: tokens, components, motion rules, page-weight check |
| T-50 | - | 24 h, new | Cart drawer, search suggestions, gallery, loading states |

| Total | Before | After |
| --- | --- | --- |
| Phase 1 Prove | 72 h | 22 h |
| Build, phases 2 to 8 | 506 h | 566 h |
| Whole backlog | 639 h | 649 h |

The net change is 10 hours, half a week at 20 hours a week, so the early July 2027 launch target holds.

## Not changed

Business rules BR-01 to BR-14, the data model, the order state machine, the money flow (ADR-002), the POS design, the ops runbook and the risk register are as in version 1.0.
