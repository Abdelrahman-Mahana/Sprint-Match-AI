# Architecture Decision Records

## Decision log

Each decision states what was chosen, why, what it costs, and what event would reopen it. A decision changes only through a new ADR that supersedes the old one. Proposed decisions become Accepted at the gate named in the last column.

| ADR | Decision | Why | Trade-off | Status | Reopen when |
| --- | --- | --- | --- | --- | --- |
| 001 | Django + PostgreSQL modular monolith | Highest score in the evaluation; control, correctness, light server | Most custom code | Proposed | Proof: WooCommerce passes all must-pass tests (then WooCommerce wins) |
| 002 | COD settles from the courier to each store's own account; the platform never holds customers' money | Avoids payment-facilitator licensing; simpler accounting | Each store needs its own courier account | Accepted | Card payments (P1) through a licensed gateway |
| 003 | Append-only stock ledger; row locks for the last unit | Makes overselling impossible and every number auditable | Slightly more code than editing a quantity | Accepted | Never |
| 004 | Money stored as integer piasters | No rounding errors | Formatting on display | Accepted | Never |
| 005 | Server-rendered shop with HTMX, not a single-page app | Fast on mid-range phones, good for search engines, one codebase | Less app-like interaction | Proposed | A native app or rich interactions are required (P2) |
| 006 | POS as an offline-capable web app | No app store; same codebase; works on any tablet | Browser printing quirks | Proposed | Proof: printer or offline test fails on the chosen hardware |
| 007 | Search inside PostgreSQL with Arabic normalization and trigrams | No extra server; enough for 3,000 to 30,000 products | Fewer search features | Accepted | Search p95 above 300 ms or quality below 18/20 |
| 008 | One 4 GB VPS behind Cloudflare; location set by the PDPL review | Under the cost ceiling | Single point of failure, mitigated by backups | Proposed | Lawyer's PDPL answer; price or availability change |
| 009 | Celery + Redis jobs with an outbox table | Retries without blocking customers; no lost or doubled messages | Two more containers | Accepted | Memory pressure on the server (switch to a PostgreSQL-backed queue) |
| 010 | A multi-store cart splits into one order and shipment per store | Matches how stores and the courier work | Customer may pay more than one delivery fee | Accepted | Pilot shows abandoned carts on multi-store checkouts |
| 011 | Stores keep their own books; the platform gives statements and exports | Keeps scope small | Accountants work from exports | Proposed | Stores ask for bookkeeping inside the platform |
| 012 | Couriers, SMS, WhatsApp and ETA behind adapter interfaces | Adding a second courier is a new adapter, not a rewrite | A little more structure up front | Accepted | Never |
| 013 | Start on Django 6.1; upgrade to 6.2 LTS after its April 2027 release | Long support to April 2030 | One upgrade during the build | Accepted | Django release policy changes |

**ADR template for new decisions:** Title · Date · Status · Context (the problem and constraints) · Options considered · Decision · Consequences (good and bad) · Reopen when.
