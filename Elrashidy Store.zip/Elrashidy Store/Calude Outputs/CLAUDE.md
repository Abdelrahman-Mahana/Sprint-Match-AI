# Al-Rashidi (الرشيدي)

An Arabic-first online marketplace for Egypt. A few invited stores (2 to 10) sell through one
shop; each store also gets a browser cashier screen (POS) on the same stock; a courier (Bosta
first) delivers and collects cash on delivery. Al-Rashidi itself is store 1. One developer
builds it, about 20 hours a week, and it must run for under 30 USD a month on one 4 GB server.

The goal for the shop is an Amazon-style experience that is cleaner, faster and better
animated, on mid-range Android phones over 4G.

## Stack

Python 3.13 · Django 6.1 · PostgreSQL 18 · Django REST Framework · Celery + Redis ·
server-rendered templates with HTMX 2 and CSS view transitions · plain CSS on design tokens ·
uv · pytest · ruff · mypy · Docker Compose · Caddy · Cloudflare.

No Node toolchain, no CSS framework, no single-page app (ADR-015, ADR-016).

## Commands

```
make setup     install dependencies, apply migrations
make run       development server on :8000
make seed      demo stores and products (DEBUG only)
make test      pytest, on real PostgreSQL
make check     lint + types + tests + migration check: run before calling a task done
make format    fix formatting
uv run pytest apps/stock -k last_unit      one test
uv run python manage.py makemigrations     after any model change
```

Tests need PostgreSQL on localhost:5432 (database, user and password all `rashidi`).
`docker compose up db redis` starts one.

## Layout

```
apps/            one Django app per module (see each app's __init__.py for its requirements)
  core/          money, StoreScopedModel, health check. No business rules
  accounts/ stores/ catalog/ search/ stock/ orders/ pos/
  shipping/ returns/ finance/ notify/ audit/
storefront/      the shop: templates, HTMX partials, CSS tokens, vendored fonts and HTMX
pos_client/      the offline cashier web app (not started)
config/          settings per environment, urls, celery
deploy/          production compose file, Caddyfile, backup script
docs/            specification, decisions, conventions, design direction
tests/           factories and cross-app tests
```

## Rules that are never broken

1. **Store isolation.** Every store-owned model inherits `StoreScopedModel`. Back-office and
   API code reads it only through `Model.objects.for_store(request.store)`. Every such view
   gets a test where another store's user receives "not found".
2. **Money is integer piasters**, in fields ending `_pt`. Never float, never `DecimalField`.
   Use `apps/core/money.py`.
3. **Stock changes only by inserting a ledger row** inside a transaction that locks the SKU's
   stock row. Never edit a quantity.
4. **The platform never holds customers' money** (ADR-002). No code path collects or pays
   out cash on a store's behalf.
5. **Apps talk through `services.py`.** No app writes another app's tables.
6. **Every state change is audited** through `apps.audit.services.record`.
7. **The shop works without JavaScript and without animation.** HTMX and view transitions
   are enhancements on top of pages that already work.
8. **Arabic is the source language** of interface text; right-to-left is the default layout.

The full list with reasons is in `docs/conventions.md`. Interface rules are in
`storefront/CLAUDE.md`.

## Where the truth is

| Need | Read |
| --- | --- |
| What to build next | `docs/spec/06_plan_and_backlog.md` (tasks T-01 to T-50, with status) |
| What a feature must do | `docs/spec/03_srs.md` (requirement IDs and acceptance criteria) |
| How it is designed | `docs/spec/04_tdd.md` (data model, order states, stock ledger, APIs, POS) |
| Business rules BR-01 to BR-14 | `docs/spec/02_prd.md` |
| Why a choice was made | `docs/decisions/` |
| How to prove it | `docs/spec/07_test_plan.md` (AT-01 to AT-21) |
| What is still undecided | `docs/open-questions.md` |

The specification is version 1.1 (15 November 2026). Older material that mentions ERPNext,
WooCommerce as a candidate, or a Saudi services marketplace is superseded; ignore it.

## Working on a task

1. Pick the task from the backlog; read the requirements it traces to and the TDD section
   for that module. The `/task` skill does this.
2. Write the failing test for each acceptance criterion first, quoting the requirement ID.
3. Build inside the owning app; expose what others need in `services.py`.
4. `make check` must pass.
5. Update the task's Status cell in the backlog, and the runbook if operations changed.

A new idea is not built on the spot: it goes to the backlog with a requirement ID. A change
to a decision is a new file in `docs/decisions/`, never an edit to an old one.

## Do not decide these in code

Commission rate, who pays for failed deliveries, free-delivery thresholds, hosting location,
tax e-receipts and return-policy wording are open with the PM, lawyer and accountant
(`docs/open-questions.md`). Make them settings and ask.

## Current state (15 November 2026)

Done: project skeleton, settings, CI, Docker files, custom user, stores and membership,
store scoping base, audit log, catalog models, Arabic normalization, money helpers, design
tokens, base theme, home and product shells with view transitions. 38 tests pass.

Not verified yet: the Docker image build and the GitHub Actions workflow have not been run.

Next: finish Foundation (T-12 to T-16), then the T-09 risk slice.
