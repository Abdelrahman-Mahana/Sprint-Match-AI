# Al-Rashidi (الرشيدي)

A multi-store marketplace for Egypt: an Arabic-first shop, a browser POS for every store,
and courier cash on delivery.

## Start

You need Python 3.13, [uv](https://docs.astral.sh/uv/) and PostgreSQL (or Docker).

```
docker compose up -d db redis    # or use your own PostgreSQL: database, user, password "rashidi"
make setup
make seed
make run                         # http://localhost:8000  (English: /en/)
```

Run `make check` before every commit. `make help` lists the other commands.

## Read next

- `CLAUDE.md`: how the project is laid out and the rules it keeps
- `docs/README.md`: map of the specification, decisions and design direction
- `docs/spec/06_plan_and_backlog.md`: what to build next

## Licences of bundled files

HTMX (0-clause BSD), Cairo and IBM Plex Sans Arabic (SIL Open Font License 1.1). The licence
texts sit next to the files under `storefront/static/storefront/`.
