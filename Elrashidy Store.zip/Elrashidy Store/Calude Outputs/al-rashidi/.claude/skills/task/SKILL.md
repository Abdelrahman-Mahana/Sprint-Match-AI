---
name: task
description: Start or continue a backlog task (T-01 to T-50). Use when the user names a task ID or asks what to build next.
argument-hint: "[task ID, for example T-27]"
---

Work on backlog task `$ARGUMENTS`. If no ID was given, read the Status column of
`docs/spec/06_plan_and_backlog.md` and propose the next task in phase order whose owner
includes Dev, then wait for agreement.

1. **Read before writing.** Find the task row in `docs/spec/06_plan_and_backlog.md`. Read
   every requirement in its "Traces to" cell in `docs/spec/03_srs.md`, the matching section
   of `docs/spec/04_tdd.md`, any business rule (BR-nn) in `docs/spec/02_prd.md`, and the
   acceptance tests that name those requirements in `docs/spec/07_test_plan.md`.
2. **Check for open questions.** If the task depends on anything in `docs/open-questions.md`,
   say so and ask before building. Do not invent a commission rate, fee or legal wording.
3. **State the plan** in a few lines: which app owns the work, the models and service
   functions to add, the tests to write. If the task is over about 8 hours, split it into
   slices that each end with passing tests.
4. **Tests first.** Write one failing test per acceptance criterion, with the requirement ID
   in its docstring. Mark tests that prove a numbered acceptance test with
   `@pytest.mark.acceptance("AT-nn")`. Anything store-owned gets an isolation test.
5. **Build** inside the owning app, following `docs/conventions.md`. Interface work also
   follows `storefront/CLAUDE.md`.
6. **Verify** with `make check`. For interface work, run the server and look at the page at
   phone width in Arabic and at desktop width in English.
7. **Close out.** Update the task's Status cell (Not started, In progress with a note, Done).
   Update `docs/spec/08_ops_runbook.md` if operations changed. Report what was built, what
   was verified and how, and anything left open.

If the work needs something the specification does not cover, stop and say what is missing.
New scope gets a requirement ID and a backlog row before any code.
