---
name: adr
description: Record a new architecture decision, or supersede an existing one. Use when a technical choice in docs/decisions or the TDD is about to change.
argument-hint: "[short title of the decision]"
---

Record a decision about: `$ARGUMENTS`.

1. Read `docs/decisions/README.md` and any record this decision touches. Check its
   "Reopen when" line: if that condition has not happened, say so before going further.
2. Take the next free number. Copy `docs/decisions/template.md` to
   `docs/decisions/NNN-short-title.md` and fill every section. "Options considered" lists
   real alternatives with their costs. "Reopen when" names an observable event.
3. A decision is made by a person. Set "Decided by" to who actually decided; if nobody has,
   leave the status as Proposed and ask.
4. Never edit the text of an accepted record. To change one, write a new record that
   supersedes it, and change only the old record's Status line.
5. Update the tables in `docs/decisions/README.md` and `docs/spec/05_decisions_adr.md`. If
   requirements, hours or tests change, update the SRS, backlog and test plan in the same
   change and say what moved.
