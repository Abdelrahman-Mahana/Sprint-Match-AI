#!/usr/bin/env bash
# Nightly backup: database dump plus media, encrypted, copied to Cloudflare R2 (Ops runbook).
# Needs: rclone remote "r2" configured, BACKUP_PASSPHRASE set, run from the deploy folder.
# Cron: 15 2 * * * /srv/rashidi/deploy/backup.sh >> /var/log/rashidi-backup.log 2>&1
set -euo pipefail

: "${BACKUP_PASSPHRASE:?Set BACKUP_PASSPHRASE}"
: "${POSTGRES_USER:?Set POSTGRES_USER}"
: "${POSTGRES_DB:?Set POSTGRES_DB}"
BUCKET="${BACKUP_BUCKET:-rashidi-backups}"
STAMP="$(date -u +%F)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

docker compose -f docker-compose.prod.yml exec -T db \
  pg_dump -U "$POSTGRES_USER" -Fc "$POSTGRES_DB" > "$WORK/db.dump"
gpg --batch --yes --pinentry-mode loopback --passphrase "$BACKUP_PASSPHRASE" \
  --symmetric --cipher-algo AES256 -o "$WORK/db.dump.gpg" "$WORK/db.dump"

rclone copy "$WORK/db.dump.gpg" "r2:$BUCKET/$STAMP/"
rclone delete "r2:$BUCKET" --min-age 30d
echo "$(date -u +%FT%TZ) backup $STAMP uploaded"
