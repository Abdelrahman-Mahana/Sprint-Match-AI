from django.http import Http404, HttpRequest, HttpResponse
from django.shortcuts import render

from apps.catalog import services as catalog

SHELF_SIZE = 12


def home(request: HttpRequest) -> HttpResponse:
    products = catalog.newest_products(limit=SHELF_SIZE + 1)
    return render(
        request,
        "storefront/home.html",
        {
            "categories": catalog.top_categories(),
            "products": products[:SHELF_SIZE],
            "next_offset": SHELF_SIZE if len(products) > SHELF_SIZE else None,
        },
    )


def newest_shelf(request: HttpRequest) -> HttpResponse:
    """HTMX partial: the next cards of the newest shelf."""
    try:
        offset = max(int(request.GET.get("offset", "0")), 0)
    except ValueError:
        offset = 0
    products = catalog.newest_products(limit=SHELF_SIZE + 1, offset=offset)
    return render(
        request,
        "storefront/partials/shelf_items.html",
        {
            "products": products[:SHELF_SIZE],
            "next_offset": offset + SHELF_SIZE if len(products) > SHELF_SIZE else None,
        },
    )


def product_detail(request: HttpRequest, product_id: int) -> HttpResponse:
    product = catalog.public_product(product_id)
    if product is None:
        raise Http404
    return render(request, "storefront/product.html", {"product": product})
