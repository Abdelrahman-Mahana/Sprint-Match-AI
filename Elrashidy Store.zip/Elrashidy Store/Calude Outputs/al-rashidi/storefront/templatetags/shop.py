from django import template
from django.utils.translation import get_language

from apps.core.money import format_egp

register = template.Library()


@register.filter
def egp(piasters: int) -> str:
    """``{{ variant.price_pt|egp }}`` → ``1,250 ج.م`` or ``EGP 1,250``."""
    return format_egp(piasters, get_language() or "ar")


@register.filter
def localized(obj: object, field: str) -> str:
    """``{{ product|localized:"name" }}``: English in English when present, else Arabic."""
    if (get_language() or "ar").startswith("en"):
        value = getattr(obj, f"{field}_en", "")
        if value:
            return value
    return getattr(obj, f"{field}_ar")
