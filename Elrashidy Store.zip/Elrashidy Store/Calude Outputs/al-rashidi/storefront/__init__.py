"""Server-rendered Arabic shop: templates, HTMX partials, design tokens (ADR-015, ADR-016).

Reads other apps through their service layers only.
"""
