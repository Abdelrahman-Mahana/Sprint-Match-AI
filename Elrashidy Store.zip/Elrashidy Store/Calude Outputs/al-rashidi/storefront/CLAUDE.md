# Storefront rules

The reasoning is in `docs/design/design-direction.md`; decisions are ADR-015 and ADR-016.

## Styling

- Every colour, size, space, radius, shadow and duration comes from a variable in
  `static/storefront/css/tokens.css`. No raw hex values, pixel sizes or millisecond values in
  component CSS. A new value means a new token, with a comment saying what it is for.
- Logical properties only: `margin-inline-start`, `padding-block`, `inset-inline-end`,
  `text-align: start`. Never `left`, `right`, `margin-left`. The same CSS serves Arabic and English.
- Mobile first. Wider layouts are added with `@media (min-width: 48rem)`.
- Touch targets are at least `var(--touch)` (44 px). Keyboard focus stays visible.
- One `button--primary` (pencil yellow) per screen. Red (`--margin`) is for discounts and errors only.
- Cards have no border box and no shadow. Only floating layers use `--shadow-float`.

## Motion

- Animate `transform` and `opacity` only. Use `--dur-fast`, `--dur-base`, `--dur-slow`; nothing longer.
- Motion answers a tap or links two pages. No entrance animations on scroll, no auto-playing carousels.
- A product picture carries `style="view-transition-name: product-{{ product.id }}"` on its
  card and on its product page. Each name appears once per page.
- All motion lives in `motion.css` and is off under `prefers-reduced-motion`.

## Behaviour

- Build the plain HTML version first: links and forms that work with scripts off. Then add
  `hx-` attributes. An HTMX endpoint returns a partial from `templates/storefront/partials/`.
- Client-side JavaScript is a last resort: a small module in `static/storefront/js/`, under
  5 KB, loaded only by the template that needs it. No frameworks, no CDN, no third-party scripts.
- Every screen has a loading, an empty and an error state, each saying what to do next (FR-UX-05).

## Text

- Arabic strings are the source: `{% translate "أضف إلى السلة" %}`. Add the English to
  `locale/en/LC_MESSAGES/django.po`.
- Plain Egyptian shop language, sentence case, no exclamation marks. A button says what it
  does, and the confirmation uses the same word.
- Prices go through `|egp`; product and store names through `|localized:"name"`.

## Budgets (checked by `tests/test_page_weight.py`)

Scripts 50 KB, styles 30 KB, fonts 160 KB, main picture 150 KB. Fonts are at 154 KB now: a
new weight needs another one removed.

## Checking a change

Run `make run` and `make seed`, then look at the page at 390 px wide in Arabic and at
1280 px in English (`/en/`). Check it with reduced motion on.
