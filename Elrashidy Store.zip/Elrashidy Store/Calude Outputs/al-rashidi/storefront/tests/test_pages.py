import pytest
from django.urls import reverse

from apps.catalog.models import Product
from apps.stores.models import Store
from tests.factories import make_product, make_store

pytestmark = pytest.mark.django_db


def test_home_is_arabic_and_right_to_left_by_default(client):
    response = client.get("/")
    assert response.status_code == 200
    html = response.content.decode()
    assert '<html lang="ar" dir="rtl">' in html
    assert "الرفوف فاضية لسه" in html  # empty state before any product exists


def test_english_is_left_to_right(client):
    response = client.get("/en/")
    assert response.status_code == 200
    assert '<html lang="en" dir="ltr">' in response.content.decode()


def test_home_shows_active_products_with_price_and_store(client):
    store = make_store(name_ar="الرشيدي")
    make_product(store, name_ar="كراسة سلك 100 ورقة", price_pt=4500)
    html = client.get("/").content.decode()
    assert "كراسة سلك 100 ورقة" in html
    assert "45 ج.م" in html
    assert "الرشيدي" in html


def test_hidden_products_and_suspended_stores_stay_out_of_the_shop(client):
    hidden = make_product(make_store(), name_ar="منتج مخفي", status=Product.Status.HIDDEN)
    suspended = make_product(make_store(status=Store.Status.SUSPENDED), name_ar="منتج محل موقوف")
    html = client.get("/").content.decode()
    assert "منتج مخفي" not in html
    assert "منتج محل موقوف" not in html
    for product in (hidden, suspended):
        assert client.get(reverse("storefront:product", args=[product.id])).status_code == 404


def test_card_and_product_page_share_a_view_transition_name(client):
    """ADR-015: the product picture travels from the card to the product page."""
    product = make_product(make_store())
    name = f"view-transition-name: product-{product.id}"
    assert name in client.get("/").content.decode()
    assert name in client.get(reverse("storefront:product", args=[product.id])).content.decode()


def test_newest_shelf_pages_with_htmx(client):
    store = make_store()
    for _ in range(14):
        make_product(store)
    home = client.get("/").content.decode()
    assert home.count('class="card"') == 12
    assert "offset=12" in home
    more = client.get(reverse("storefront:newest-shelf"), {"offset": 12}).content.decode()
    assert more.count('class="card"') == 2
    assert "hx-get" not in more  # nothing left to load
