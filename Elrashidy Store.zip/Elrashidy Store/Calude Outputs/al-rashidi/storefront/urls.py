from django.urls import path

from . import views

app_name = "storefront"

urlpatterns = [
    path("", views.home, name="home"),
    path("shelf/newest", views.newest_shelf, name="newest-shelf"),
    path("p/<int:product_id>", views.product_detail, name="product"),
]
