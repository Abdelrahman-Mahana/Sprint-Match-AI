# Documentation map

| Folder or file | What it holds |
| --- | --- |
| `spec/` | The specification, version 1.1: overview, PRD, SRS, TDD, decisions table, plan and backlog, test plan, ops runbook, risks. `CHANGES-2026-11-15.md` lists what version 1.1 changed |
| `spec/originals/` | The version 1.0 PDFs the markdown was converted from |
| `spec/drawings/` | Order journey, data model, order state machine, timeline, architecture |
| `decisions/` | Decision records. 001 to 013 are rows in `spec/05_decisions_adr.md`; 014 on are files |
| `conventions.md` | The rules the code follows, with reasons |
| `design/design-direction.md` | Palette, type, spacing, motion and layout, and why |
| `open-questions.md` | Business, legal and product questions that people must answer |

If two documents disagree, the order of authority is: a decision record, then the SRS, then
the TDD, then everything else. Tell the PM about the disagreement.

The markdown in `spec/` was converted from PDF by script. Tables converted cleanly; a few
bulleted lists run together into one paragraph. Where a sentence reads oddly, check the PDF.

## Live documents

- English specification: https://claude.ai/artifact/8uFb7W7zFEKssWxSe6aVCY (version 1.0 tabs, plus a "Version 1.1 changes" tab)
- Arabic specification: https://claude.ai/artifact/FLatqzUhmVDXrkX1TQHqsE (version 1.0; not yet updated)
- Storefront design canvas: https://claude.ai/artifact/MZbXP9j5wJkKv8SgkHpv3n

The markdown in `spec/` is the working copy for development and is the only place where
version 1.1 is applied row by row.
