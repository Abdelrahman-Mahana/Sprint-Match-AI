# Open questions

These belong to people, not to the code. Do not settle them by guessing in a migration or
a constant. Where code needs a value now, make it a per-store setting or a named constant
that points back to this file.

## Business rules still "to confirm" (PRD)

| Question | Owner | Where it lands in code |
| --- | --- | --- |
| Default commission rate, and whether it varies by category | PM with owners | `Store.commission_bps` (BR-05) |
| Who pays the return fee for a failed delivery: store or platform | PM with owners | finance, returns (BR-10) |
| Free-delivery threshold per store, if any | Each store | store setting (BR-04) |
| Whether counter (POS) sales carry commission; default no | PM with owners | finance (BR-06) |
| Commission cover target and its review date | PM | none |

## Legal and tax

| Question | Owner | Blocks |
| --- | --- | --- |
| Hosting location or cross-border licence under the data protection law (PDPL) | Lawyer | Ordering the production server (ADR-008) |
| Return-policy wording; whether books are excluded from no-reason returns | Lawyer | Returns flow copy (BR-08) |
| Whether each store is named for e-receipts by the tax authority (ETA) | Accountant, per store | E-receipt adapter (P2) |
| Written partnership agreement: pay or share, running costs, code ownership, exit | Owner, PM | Nothing technical; it is task T-01 and the top project risk |

## Product, raised on 15 November 2026

| Question | Owner | Default until answered |
| --- | --- | --- |
| Keep search suggestions in the MVP (FR-UX-03), or return them to P1? | PM | In the MVP as a Should |
| Approve the proposed palette, fonts and motion direction; supply the corrected logo «الرشيدي» | Owner, designer | Tokens as written; the wordmark is set in Cairo |
| Which P1 shopping features come first: reviews, wishlist, recently viewed, more from this store | PM | None are built |
