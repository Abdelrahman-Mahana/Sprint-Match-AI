# Conventions

Rules the code follows. Each has a reason and, where one exists, the file to copy.

## Architecture

1. **One Django app per module; talk through services.** Each app owns its tables. Another
   app calls functions in `services.py` and never creates, updates or deletes that app's rows
   itself. Foreign keys to another app's model, and read queries that join through them, are
   fine. Example: `apps/catalog/services.py` reads `store__status` through a constant that
   `apps/stores/services.py` exports.
2. **Dependency direction** follows `LOCAL_APPS` in `config/settings/base.py`: an app may
   call apps listed above it, never below. `storefront` and `pos` sit at the bottom and call
   everything; `core`, `accounts` and `audit` sit at the top and call nothing.
3. **Views are thin.** A view parses input, calls one service, renders. Rules live in services.
4. **Every state change goes through a service function that writes the audit log**
   (`apps.audit.services.record`). Price, stock, refund, commission and permission changes
   record old and new values (NFR-AUD-01).

## Stores and isolation

5. **Every store-owned model inherits `StoreScopedModel`** (`apps/core/models.py`), which gives
   it a non-null `store` and the `for_store()` manager. Copy `apps/catalog/models.py`.
6. **Back-office and API code reads store-owned rows only through
   `Model.objects.for_store(request.store)`.** The shop is the one exception, because shoppers
   see every active store; those reads live in a service function named `public_*` or
   `_public_*`.
7. **Every new back-office view or API gets an isolation test:** a user of store 2 asks for a
   store 1 record and gets "not found" (AT-02).

## Money, stock and time

8. **Money is integer piasters.** Fields and variables end in `_pt`. Never `float`, never
   `DecimalField`. Parse with `to_piasters`, show with `format_egp` or the `|egp` template
   filter, take shares with `percent_of` (`apps/core/money.py`).
9. **Stock changes only by inserting a `stock_move` row** inside a transaction that locks the
   SKU's `stock_level` row with `select_for_update()`, in SKU order (ADR-003, TDD "Stock
   ledger and concurrency"). Nothing edits a quantity in place.
10. **Order placement and POS sync are idempotent**: an `Idempotency-Key` header for checkout,
    a client UUID per POS sale. A repeat returns the first result.
11. **Times are stored in UTC and shown in Africa/Cairo.** Use `django.utils.timezone.now()`.

## Integrations

12. **Couriers, SMS, WhatsApp and ETA sit behind adapter interfaces** (ADR-012). Business code
    never imports a provider's client.
13. **Outbound calls go through the outbox and a Celery job** with retries; failures appear on
    a "needs attention" list. **Inbound webhooks are stored raw first**, then processed by a job.

## Language and interface

14. **Arabic is the source language of interface text.** Wrap every string in
    `{% translate %}` or `gettext`; the English goes in `locale/en/LC_MESSAGES/django.po`.
    Write Arabic the way an Egyptian shopper speaks, not a literal translation of English.
15. **Data carries both languages** as `name_ar` (required) and `name_en` (optional); templates
    pick with `|localized:"name"`.
16. **Accept Arabic and Latin digits in every input** (NFR-L10N-01).
17. **Interface rules** (tokens, motion, right-to-left) are in `storefront/CLAUDE.md` and
    `docs/design/design-direction.md`.

## Tests

18. **Test first for rules.** A task starts with a failing test named after the requirement's
    acceptance criterion, and quotes its ID in the docstring.
19. **Tests run on real PostgreSQL**, never SQLite: locking, constraints and search behave
    differently.
20. **Acceptance tests carry `@pytest.mark.acceptance("AT-03")`** so the release checklist
    can list which are covered.
21. Build test data with the plain functions in `tests/factories.py`.

## Code style

22. `ruff` formats and lints; `mypy` checks types. Public service functions have type hints.
23. Comments say why, not what. A requirement, rule or decision ID in a docstring is welcome.
24. Migrations stay backward compatible for one release, so a rollback never needs a restore.
25. No new dependency without a line in the pull request saying why the standard library or
    Django cannot do it.
