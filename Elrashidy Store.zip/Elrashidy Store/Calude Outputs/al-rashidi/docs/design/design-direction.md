# Design direction

Proposed on 15 November 2026. The owner and designer still need to approve it (task T-07),
and the corrected logo is outstanding. The live tokens are in
`storefront/static/storefront/css/tokens.css`; this page explains them.

## The idea

Al-Rashidi sells books, copybooks, pens and school bags. The interface borrows from that
world: the page is a sheet of cream paper, text is navy ink, dividers are the ruled lines of
a copybook, and each section title starts at a short red margin line. Products sit in rows on
a ruled line, like things on a shelf. The one loud colour is pencil yellow, kept for the
single main action on a screen.

Everything else stays quiet so that product photos carry the page.

## Colour

| Token | Value | Named for | Used for |
| --- | --- | --- | --- |
| `--ink` | `#132042` | Navy ink | Header, headings, body text |
| `--paper` | `#FBF6EA` | Cream paper | Page background |
| `--sheet` | `#FFFDF8` | A clean sheet | Cards, fields, drawers |
| `--rule` | `#E2D8C0` | Copybook ruled line | Dividers and borders |
| `--graphite` | `#5A6172` | Pencil lead | Secondary text |
| `--pencil` | `#F2B705` | Pencil yellow | The one primary action per screen |
| `--margin` | `#C81E3A` | Copybook margin line | Discounts, errors, the section tick |
| `--stamp` | `#1B6E52` | Rubber stamp | In stock, delivered, success |

Rules: text on `--pencil` is always `--ink`. Red never means "buy". A screen has one
pencil-yellow button at most.

Contrast, calculated: ink on paper 14.8:1; graphite on paper 5.7:1; ink on pencil 8.8:1;
margin red on paper 5.3:1; stamp green on paper 5.7:1. All pass the 4.5:1 target
(NFR-A11Y-01).

## Type

| Role | Family | Weight | Notes |
| --- | --- | --- | --- |
| Display: wordmark, page and section titles | Cairo | 700 | Wide, confident Arabic forms |
| Everything read: names, prices, body, controls | IBM Plex Sans Arabic | 400, 600 | Clear at 14 px on a phone; 600 for prices and buttons |

Sizes run 12, 14, 16, 18, 22, 28, 36 px. Body line height is 1.7 because Arabic needs room
above and below the line; headings use 1.3. Prices use tabular figures and Latin digits.

## Space and shape

Spacing is a 4 px scale (`--space-1` to `--space-8`). Touch targets are at least 44 px.
Three radii carry meaning: labels and tickets are cut nearly square (4 px), pictures are
soft (12 px), and controls you press are pills.

There is one shadow, tinted with ink, and only things that float over the page use it
(drawer, sheet, toast). Cards have no box and no shadow: the picture is the card.

## Motion

Motion has two jobs: answer a tap, and carry the eye from one page to the next.

| Moment | What moves | Timing |
| --- | --- | --- |
| Open a product | Its picture travels from the card to the product page; the rest cross-fades | 320 ms, ease in-out |
| Add to cart | Button confirms; the cart count ticks; the drawer slides in from the end edge | 200 ms, ease out |
| Press anything | Scales to 97% | 120 ms |
| New content arrives (show more, suggestions) | Fades in | 200 ms |

Rules (NFR-UX-01): transform and opacity only; nothing longer than 320 ms; nothing animates
on its own, so no entrance animations on scroll and no carousels that move by themselves;
all of it is off under reduced motion, and the page works the same without it.

## Layout

Mobile first, because that is where the customers are.

```
┌──────────────────────────┐   Header: navy. Wordmark at the start edge,
│ الرشيدي          🛒  EN │   cart and language at the end edge.
│ [ ابحث عن كراسة، قلم… ] │   Search is the first thing under it.
├──────────────────────────┤
│ (قسم) (قسم) (قسم) (قسم) →│   Category chips: one scrolling row.
│                          │
│ ▌وصل حديثًا              │   Shelf title on a ruled line,
│ ─────────────────────────│   red margin tick at the start.
│ ┌────┐ ┌────┐ ┌────┐     │
│ │    │ │    │ │    │  →  │   Products scroll sideways on phones,
│ └────┘ └────┘ └────┘     │   wrap into a grid from 768 px.
│ اسم    اسم    اسم        │
│ 45 ج.م 85 ج.م 35 ج.م     │
└──────────────────────────┘
```

Text aligns to the start edge everywhere (right in Arabic, left in English). Nothing is
centred except the content of buttons and chips.

## What "like Amazon, but better" means here

Keep what shoppers already know from Amazon: search first, dense shelves, the price and the
seller on every card, a yellow buy button, a cart you can reach from anywhere.

Do better where Amazon is weak: one clear action per screen instead of many; no clutter of
badges and banners; the cart shows each store's delivery fee before checkout, not after;
pages that feel connected because the picture you tapped is the picture you land on.

## Screens

The key screens (home, category, product, cart, checkout, order tracking) are drawn in the
design canvas [Al-Rashidi storefront: design direction](https://claude.ai/artifact/MZbXP9j5wJkKv8SgkHpv3n).
Product names, prices and the second store in it are sample data; delivery fees and order
numbers are placeholders in square brackets. The repository implements the base
theme, home and product shells so far.
