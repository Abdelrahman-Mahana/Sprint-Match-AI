# ADR-014: Commit to Django + PostgreSQL; drop the WooCommerce comparison

- Date: 15 November 2026
- Status: Accepted
- Decided by: PM
- Supersedes: the "Proposed" status of ADR-001, which is now Accepted

## Context

ADR-001 chose Django + PostgreSQL as the default and left it Proposed until a two-week test
against WooCommerce + Dokan + wePOS (tasks T-09 to T-11, 66 hours). On 15 November the PM
set a new goal: an Amazon-style shopping experience with better interface, motion and speed.

## Options considered

1. Run the comparison as planned.
2. Commit to Django now.

## Decision

Commit to Django now. A custom storefront with its own motion and speed budgets is the part
WooCommerce would constrain most, so a comparison could only confirm the choice or push the
project toward a stack that fights its main goal.

## Consequences

- About 50 hours return to the build: T-10 is dropped, T-11 is done, T-09 shrinks to a
  16-hour risk slice.
- Tests AT-01 to AT-11 stop being a "proof" and stay as must-pass acceptance tests.
- There is no fallback stack on the shelf. The mitigation is T-09: prove last-unit locking
  and the POS on the real tablet and printer before the phases that depend on them.
- The spec's appendix on the WooCommerce path is history, not a plan.

## Reopen when

A must-pass acceptance test cannot be met on this stack within its phase.
