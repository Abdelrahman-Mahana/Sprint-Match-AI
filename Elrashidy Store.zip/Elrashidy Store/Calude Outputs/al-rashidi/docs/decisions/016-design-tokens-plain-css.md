# ADR-016: Design tokens, plain CSS, self-hosted assets, no front-end build step

- Date: 15 November 2026
- Status: Accepted
- Decided by: PM

## Context

The earlier drafts carried two colour palettes and two font sets (risk R-14). The storefront
now has speed, page-weight and motion budgets, and one developer maintains it.

## Options considered

1. A utility CSS framework with a Node build step.
2. A component library.
3. One token file and hand-written modern CSS.

## Decision

Option 3.

- `storefront/static/storefront/css/tokens.css` is the only place colours, type sizes,
  spacing, radii, shadows and motion timings are defined. Components use the variables.
- CSS uses logical properties (`margin-inline`, `inset-inline-start`) so one rule set serves
  right-to-left Arabic and left-to-right English.
- Fonts (Cairo, IBM Plex Sans Arabic; both under the SIL Open Font License) and scripts
  (HTMX) are files in the repository with their versions in the file name. Shop pages make
  no third-party requests.
- There is no Node toolchain. Django's static files pipeline fingerprints and compresses.

## Consequences

- Nothing to compile, nothing extra to patch, and the same files run locally and in production.
- Buttons, fields, drawers and the rest are written once by hand (task T-49).
- Without a framework's guard rails, the rule "no raw values in component CSS" is kept by
  review and by the `ui-reviewer` agent.

## Reopen when

The stylesheet passes its 30 KB budget, or hand-written components slow delivery.
