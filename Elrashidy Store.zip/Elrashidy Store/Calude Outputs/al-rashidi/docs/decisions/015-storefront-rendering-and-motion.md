# ADR-015: Server-rendered storefront with view transitions and small interactive parts

- Date: 15 November 2026
- Status: Accepted
- Decided by: PM
- Supersedes: ADR-005

## Context

ADR-005 chose server-rendered pages with HTMX because they are fast on mid-range phones,
good for search engines and one codebase. Its reopen trigger was "rich interactions are
required". The PM now wants an interface that feels better than Amazon's, with animation,
without giving up speed. Most customers are on mid-range Android phones over 4G, and the
whole platform runs on one 4 GB server.

## Options considered

1. **Server-rendered pages + HTMX + cross-document view transitions + small scripts.**
   One codebase, almost no JavaScript to download, app-like movement from the browser itself.
2. **A separate Next.js (React) storefront on the Django API.** Most freedom for animation.
   Costs a second codebase, a Node process on the same small server, more JavaScript on the
   phone, and more build hours.

## Decision

Option 1.

- Every page is complete HTML from Django. It works with scripts off.
- **Page-to-page motion** uses cross-document view transitions (`@view-transition` in CSS).
  A product's picture carries the same `view-transition-name` on its card and on its product
  page, so the browser moves it between the two.
- **In-page updates** (cart drawer, search suggestions, "show more") are HTMX requests that
  return HTML partials.
- **Small interactive parts** that need client state (photo gallery, drawer focus handling)
  are plain JavaScript modules, each under 5 KB, loaded only on pages that use them.
- The motion rules and budgets are requirements: NFR-UX-01, NFR-PERF-01, NFR-PERF-03.

## Consequences

- Speed comes first by construction. On 15 November 2026 a first visit downloads HTML,
  4 KB of CSS and 17 KB of HTMX (both compressed).
- View transitions are an enhancement. Chromium and Safari have them; a browser without
  them loads pages normally. Nothing may depend on a transition having run.
- Very elaborate choreography (shared layout animation across many elements, gesture-driven
  physics) is out of reach. That is accepted.
- Templates must give matching `view-transition-name` values on both pages, and each name
  must be unique within a page.

## Reopen when

The speed or motion targets cannot be met this way, or a native app is required (P2).
