# ADR-NNN: Title

- Date:
- Status: Proposed | Accepted | Superseded by ADR-NNN
- Decided by:

## Context

The problem and the constraints.

## Options considered

## Decision

## Consequences

Good and bad.

## Reopen when
