# Decision records

A decision changes only through a new record that supersedes the old one. The summary table
of all sixteen is in [../spec/05_decisions_adr.md](../spec/05_decisions_adr.md). Decisions
001 to 013 were written as table rows on 9 November 2026; from 014 on, each has its own file.

| ADR | Decision | Status |
| --- | --- | --- |
| 001 | Django + PostgreSQL modular monolith | Accepted (by 014) |
| 002 | Cash on delivery settles from the courier to each store; the platform never holds customers' money | Accepted |
| 003 | Append-only stock ledger; row locks for the last unit | Accepted |
| 004 | Money stored as integer piasters | Accepted |
| 005 | Server-rendered shop with HTMX, not a single-page app | Superseded by 015 |
| 006 | POS as an offline-capable web app | Proposed until T-09 proves it on the real hardware |
| 007 | Search inside PostgreSQL with Arabic normalization and trigrams | Accepted |
| 008 | One 4 GB server behind Cloudflare; location set by the data-protection review | Proposed until the lawyer answers |
| 009 | Celery + Redis jobs with an outbox table | Accepted |
| 010 | A multi-store cart splits into one order and shipment per store | Accepted |
| 011 | Stores keep their own books; the platform gives statements and exports | Proposed |
| 012 | Couriers, SMS, WhatsApp and ETA behind adapter interfaces | Accepted |
| 013 | Start on Django 6.1; upgrade to 6.2 LTS after April 2027 | Accepted |
| [014](014-commit-to-django.md) | Commit to Django now; drop the WooCommerce comparison | Accepted |
| [015](015-storefront-rendering-and-motion.md) | Server-rendered storefront with view transitions and small interactive parts | Accepted |
| [016](016-design-tokens-plain-css.md) | Design tokens, plain CSS, self-hosted assets, no build step | Accepted |

New records copy [template.md](template.md).
