# Software Requirements Specification (SRS)

> Version 1.1, 15 November 2026. Converted from the specification document; the PDFs in `originals/` are version 1.0. Everything that changed on 15 November is listed in [CHANGES-2026-11-15.md](CHANGES-2026-11-15.md) and marked **(v1.1)** below.

Purpose and conventions This SRS states what the MVP must do, in testable terms. It follows the spirit of ISO/IEC/IEEE 29148: each requirement is single, verifiable and traceable. IDs: FR-<module>-<nn> for functional requirements, NFR-<area>-<nn> for non- functional ones, BR-nn for the business rules in the PRD. Priority: Must = MVP blocker. Should = MVP if time allows. Could = P1 candidate. Words: "shall" marks a requirement. "Store user" means any role inside one store. Trace: every Must requirement has a test in the Test plan and a task in the backlog. Modules: CAT catalog, SRC search, CHK cart and checkout, ORD orders, STK stock, POS point of sale, SHP courier and shipping, RET returns, FIN commission and statements, NTF notifications, ADM administration, RPT reports, SEC security. Roles and permissions Every store-level permission is limited to the user's own store. A store user can never read or change another store's data (FR-SEC-02).

| Capability | Customer | Cashier | Store staff | Store manager | Platform admin | Accountant (read) |
| --- | --- | --- | --- | --- | --- | --- |
| Browse, order, track, request return | Yes |  |  |  |  |  |
| POS sale, refund at counter, drawer count |  | Yes |  | Yes |  |  |
| Pack orders, print labels, receive returns |  |  | Yes | Yes |  |  |
| Products, prices, stock counts, purchase receipts |  |  |  | Yes |  |  |
| Approve count differences and price changes |  |  |  | Yes |  |  |
| Store reports and statement |  |  |  | Yes | Yes | Yes |
| Invite stores, set commission, approve products |  |  |  |  | Yes |  |
| Coupons (platform-funded) |  |  |  |  | Yes |  |
| Coupons (store-funded) |  |  |  | Yes | Yes |  |
| Users and roles inside a store |  |  |  | Yes | Yes |  |
| All stores' data, audit log, settings |  |  |  |  | Yes | Read |

### Functional requirements

There are 57 requirements, 51 of them Must **(v1.1: FR-UX-01 to 05 added)**. Sorted by module.

| ID | The system shall | Priority | Acceptance criteria |
| --- | --- | --- | --- |
| FR-CAT-01 | Store each product under exactly one store, with Arabic and English name, description, category, price, cost, barcode, images | Must | A product without a store or an Arabic name cannot be saved |
| FR-CAT-02 | Support variants (e.g. colour, size), each with its own SKU, price and stock | Must | A variant sells and counts stock independently |
| FR-CAT-03 | Import and update products by CSV per store, matched on SKU | Must | 3,000 rows import in under 5 minutes; re-import updates and never duplicates; a row error report is produced |
| FR-CAT-04 | Resize and store product images in object storage and serve WebP | Must | Product page images are under 150 KB each on mobile |
| FR-CAT-05 | Let the platform admin approve or hide a product | Should | A hidden product disappears from search and the shop within a minute |
| FR-CAT-06 | Show each product's store name on the product page | Must | Store name and link visible on every product |
| FR-SRC-01 | Normalize Arabic before search: hamza forms (ا آ إ أ), ta marbuta and ha (ه ة), alif maqsura and ya (ي ى), diacritics, tatweel, Arabic and Latin digits | Must | 18 of 20 real spelling-variant queries return the right item first |
| FR-SRC-02 | Rank by name match, then category, then store; tolerate one-letter typos | Must | Tested with the 20-query set |
| FR-SRC-03 | Filter by category, store, price range and in-stock | Must | Filters combine correctly |
| FR-SRC-04 | Show a helpful no-results page with suggestions | Should | Empty results show categories and best sellers |
| FR-CHK-01 | Allow guest checkout with name, phone, governorate, area and address | Must | Order placed without an account |
| FR-CHK-02 | Verify the phone with a one-time code before confirming | Must | No order is confirmed without a verified phone; 5 tries per hour |
| FR-CHK-03 | Split a multi-store cart into one order per store, each with its own delivery fee, shown before confirming | Must | 2-store cart creates 2 orders under 1 order group; totals match |
| FR-CHK-04 | Price delivery from the courier zone table | Must | Fee equals the table for 10 sample addresses |
| FR-CHK-05 | Apply one coupon per order group with expiry, usage limit and funder | Must | A second coupon is refused; an expired one is refused |
| FR-CHK-06 | Make order placement idempotent | Must | A double tap or network retry creates one order group |
| FR-CHK-07 | Block checkout of items that are out of stock | Must | Out-of-stock items cannot be added or checked out |
| FR-ORD-01 | Move each order through the states in the TDD state machine and log every change | Must | Invalid transitions are refused; history shows who and when |
| FR-ORD-02 | Give the customer a private tracking link per order group | Must | Link shows each store's order status without login |
| FR-ORD-03 | Let the customer cancel free until the parcel is handed to the courier | Must | Cancel releases reserved stock immediately |
| FR-ORD-04 | Give store staff a pick list and pack slip per order | Must | A picker completes an order from the slip alone |
| FR-STK-01 | Record every stock change as a ledger entry with type, quantity, reference and user | Must | On-hand equals the sum of ledger entries for every SKU |
| FR-STK-02 | Reserve stock when an online order is confirmed and release it on cancel or failure | Must | Available = on hand - reserved, at all times |
| FR-STK-03 | Never let online and POS sales together sell more than on hand | Must | Concurrent last-unit test: one sale succeeds, stock ends at 0 |
| FR-STK-04 | Support cycle counts with manager approval of differences | Must | Unapproved counts change nothing; approved differences post with reason |
| FR-STK-05 | Record purchase receipts from suppliers with quantity and unit cost | Must | Receipt increases stock and updates average cost |
| FR-STK-06 | Alert the store manager when available stock falls to the reorder level | Must | Alert sent once per crossing |
| FR-POS-01 | Run in a browser on a tablet or PC with barcode scanner input | Must | Scan adds the item in under 1 second |
| FR-POS-02 | Keep selling for at least 1 hour offline and sync without loss or duplicates | Must | 50-sale test with 1 hour offline loses nothing |
| FR-POS-03 | Print an 80 mm receipt with store details | Must | Receipt prints on the chosen printer |
| FR-POS-04 | Process counter refunds and exchanges against the original receipt | Must | Refund restocks and records the cash out |
| FR-POS-05 | Open and close a cash drawer session with count and variance | Must | Variance shown per session and per cashier |
| FR-POS-06 | Give each cashier their own login with access only to their shift | Must | A cashier cannot see another cashier's session |
| FR-SHP-01 | Create a courier shipment per order, with COD amount, and print the label | Must | Label prints; tracking number saved on the order |
| FR-SHP-02 | Receive courier status webhooks, verify them, and update order status | Must | Status matches the courier within 5 minutes; forged calls are rejected |
| FR-SHP-03 | Poll the courier hourly for shipments with no update in 24 hours | Must | Stuck shipments are listed for staff |
| FR-SHP-04 | Import the courier's settlement data and match it to orders | Must | Every delivered order matches a settlement line or is flagged |
| FR-RET-01 | Let the customer request a return within the allowed period | Must | Requests outside the period are refused with the reason |
| FR-RET-02 | Book a courier return pickup and record the inspection result (restock or write-off) | Must | Stock and statement are correct after both outcomes |
| FR-RET-03 | Record the refund against the order and the statement | Must | Statement shows the refund in the right month |
| FR-FIN-01 | Calculate commission on delivered item value per BR-05 | Must | Matches a hand calculation to the piaster |
| FR-FIN-02 | Produce a monthly statement per store, with CSV and PDF export | Must | Statement totals equal the sum of its lines |
| FR-FIN-03 | Let the store manager accept or dispute the statement | Must | Disputes are listed for the admin with comments |
| FR-FIN-04 | Issue a numbered commission invoice per store per month | Must | Numbers have no gaps; invoice ties to the statement |
| FR-NTF-01 | Send order messages (confirmed, shipped, delivered, return accepted) by SMS or WhatsApp | Must | Sent within 1 minute; failures retried and logged |
| FR-NTF-02 | Keep marketing messages off unless the customer opted in | Must | No marketing message to a customer without a stored consent |
| FR-ADM-01 | Let the admin invite a store, set its commission and courier account, and activate it | Must | A new store can sell after activation only |
| FR-ADM-02 | Let the admin suspend a store, hiding its products without deleting data | Should | Suspended store's products vanish; orders in progress continue |
| FR-RPT-01 | Show daily sales by channel (online, POS), stock valuation, low stock, statement | Must | Figures tie to the ledger and statements |
| FR-RPT-02 | Show margin per product from cost and price | Should | Margin shown where cost exists |
| FR-UX-01 | **(v1.1)** Animate page-to-page navigation; a product's picture travels from its card to its product page | Must | Works in current Chromium and Safari; with reduced motion on or no browser support, the page loads normally |
| FR-UX-02 | **(v1.1)** Add to cart without leaving the page, and show a cart drawer grouped per store with each store's delivery fee | Must | The cart count updates on the server's reply; with scripts off, the same button works as a normal form |
| FR-UX-03 | **(v1.1)** Suggest products and categories while the customer types in search | Should | Suggestions answer in under 300 ms at the 95th percentile; Enter always opens the full results page |
| FR-UX-04 | **(v1.1)** Let the customer swipe between product photos and zoom in | Should | Swiping is smooth on a mid-range Android phone; photos are reachable by keyboard |
| FR-UX-05 | **(v1.1)** Show a state for every wait and every empty or failed result, each with a next step | Must | No screen is blank while loading; every empty and error state names what to do next |
| FR-SEC-01 | Enforce two-factor login for store managers and admins | Must | Login without the second factor fails |
| FR-SEC-02 | Scope every store-level query to the user's store | Must | Store-isolation test passes for every screen and API |

Non-functional requirements

| ID | Area | Requirement | How it is checked |
| --- | --- | --- | --- |
| NFR-PERF-01 | Speed | **(v1.1)** On a mid-range Android phone over 4G, home, category and product pages meet: largest content visible in 2.5 s or less, response to a tap in 200 ms or less, layout shift 0.1 or less; server response under 500 ms at the 95th percentile | Lighthouse (mobile) in CI, field check on a real phone, load test |
| NFR-PERF-02 | Capacity | Handle 5 times the expected peak (start: 50 concurrent users) on a 4 GB server | k6 load test before launch and before back-to-school season |
| NFR-PERF-03 | Page weight | **(v1.1)** First visit to home, category or product: scripts 50 KB or less, styles 30 KB or less, fonts 160 KB or less (all compressed), and the main picture 150 KB or less. No third-party scripts on shop pages | Budget check in CI |
| NFR-AVL-01 | Availability | 99.5% monthly for the shop and POS sync, excluding announced maintenance | Uptime monitor |
| NFR-REC-01 | Recovery | Lose at most 24 h of data at MVP and about 1 h in P1; restore within 4 h | Monthly restore drill |
| NFR-POS-01 | Offline | POS works 1 hour without internet; sales sync once, in order | POS offline test |
| NFR-L10N-01 | Language | Arabic first, right-to-left; English second; EGP; Africa/Cairo time zone; Arabic and Latin digits accepted in every input | UI review on real phones |
| NFR-UX-01 | Motion | **(v1.1)** Animations move and fade only (transform and opacity); none runs longer than 320 ms; none delays a tap; all are off when the device asks for reduced motion; nothing animates on its own | Playwright check plus review on a real phone |
| NFR-A11Y-01 | Accessibility | WCAG 2.2 AA targets: 4.5:1 text contrast, 44 x 44 px touch targets, visible focus | Automated check plus manual review |
| NFR-SEC-01 | Security | OWASP ASVS level 1 controls; TLS everywhere; secrets outside the code; dependency scanning in CI | Security checklist before launch |
| NFR-PRIV-01 | Privacy | Collect only the personal data needed; PDPL licence path agreed with the lawyer before launch | Legal sign-off |
| NFR-AUD-01 | Audit | Price, stock, refund, commission and permission changes record who, when, old and new value | Audit report review |
| NFR-MNT-01 | Maintainability | Business logic covered by automated tests (target 80% of the core modules); one command builds the full environment | CI report |
| NFR-COST-01 | Cost | Running cost under 30 USD a month at launch | Monthly invoice review |
| NFR-SEO-01 | Search visibility | Arabic page titles, clean URLs, sitemap, product structured data | Search Console |

External interfaces

| System | Used for | Direction | Notes |
| --- | --- | --- | --- |
| Courier (Bosta first) | Create shipments with COD, labels, tracking, return pickups, settlement data | Platform calls the API; courier sends status webhooks | One API key per store's courier account. Staging environment available. Community SDKs exist for Python and Node (bostaSDK, bosta-nodejs); confirm endpoints in Bosta's own docs |
| SMS provider (Egyptian aggregator) | Phone OTP, order messages | Platform calls the API | Sender name registration needed; quotes pending |
| WhatsApp Business Platform (via a provider) | Order messages | Platform calls the API | Billed per delivered template message since July 2025 (Meta) |
| Cloudflare | DNS, CDN, firewall, rate limits; R2 for images and backups | In front of the server | Free plan at launch |
| ETA e-receipt and e-invoice APIs | Only for stores named in an e- receipt decision, and commission e- invoices if the platform is VAT- registered | Platform calls ETA | P2 unless a store is named earlier |
| Barcode scanner, receipt printer | POS input and receipts | Browser keyboard input; printer via the browser print dialog or a local print helper | Test the exact printer model in the proof |

### Data, retention and privacy

Egypt's data protection law is now in force, and it affects hosting. The PDPL executive regulations were issued on 1 November 2025 (Decree 816/2025). Controllers and processors need a licence or permit. Storing or processing personal data outside Egypt needs its own licence (Al Tamimi). The one-year grace period ended on 1 November 2026 (Soliman Hashish via Mondaq). A server in Germany therefore needs a cross-border licence, or customer data must be hosted in Egypt. The lawyer decides this before launch.

| Data | Examples | Kept for | Notes |
| --- | --- | --- | --- |
| Customer contact | Name, phone, address | 2 years after the last order (to confirm) | Needed for delivery and returns only |
| Orders, invoices, statements | Lines, prices, taxes, commission | 5 years | Matches the ETA archiving period (Thomson Reuters) |
| Stock ledger and audit log | Movements, approvals, changes | 5 years | Never edited; corrections are new entries |
| OTP codes | Verification codes | 10 minutes | Stored hashed |
| Marketing consent | Opt-in time, channel, withdrawal | While active plus 2 years | Separate licence and explicit consent required for e-marketing |
| Staff accounts | Name, role, store, login history | While employed plus 1 year |  |
| Backups | Full copies | 30 days | Encrypted |

### Rules for every feature:

Collect the minimum. Keep card data out of the platform entirely. Never send customer names or phones to outside AI services. Notify the data protection centre within 72 hours of a breach (same Al Tamimi source).
