# Al-Rashidi Platform: Product and Technical

> Version 1.1, 15 November 2026. Converted from the specification document; the PDFs in `originals/` are version 1.0. Everything that changed on 15 November is listed in [CHANGES-2026-11-15.md](CHANGES-2026-11-15.md) and marked **(v1.1)** below.

Specification Nov 9, 2026 · @Abdulrahman This set specifies the Al-Rashidi multi-store platform for Egypt: invited stores, an online shop, a POS in every store, and courier cash on delivery. Version 1.0 is a draft for review. The technical tabs assume Django + PostgreSQL, the default pending the two-week proof. Document map Each tab answers one question for one reader. Read them in this order:

| Tab | Answers | Main reader |
| --- | --- | --- |
| PRD | What we build, for whom, and how we know it worked | Owner, partners, PM |
| SRS | Exactly what the software must do, with IDs and acceptance criteria | Developer, tester |
| TDD | How it is built: architecture, data, states, APIs, security | Developer |
| Decisions (ADR) | Why each technical choice was made, and what would reopen it | PM, developer |
| Plan and backlog | Phases, gates and every task with an owner and status | PM, whole team |
| Test plan | How each requirement is proven before release | Tester, PM |
| Ops runbook | How to deploy, back up, restore and handle incidents | Whoever runs the server |
| Risks and watch list | What could go wrong, what to re-check and when, pro tips and future plan | PM, owner |

IDs link the tabs. A requirement such as FR-ORD-03 in the SRS appears in the TDD design,

the backlog task and the test that proves it. Decisions already made Seven decisions are fixed. Five are still open, and the PRD lists them with owners.

| Date | Decision | Made by |
| --- | --- | --- |
| 8 Nov 2026 | A multi-store platform for a few invited stores (about 2 to 10); open sign-up later | PM |
| 8 Nov 2026 | 3,000+ products at launch | PM |
| 8 Nov 2026 | A courier company delivers and collects cash on delivery | PM |
| 8 Nov 2026 | POS, stock counts and purchasing for every store | PM |
| 8 Nov 2026 | Default stack Django + PostgreSQL; WooCommerce + Dokan + wePOS is the challenger in a two-week proof (superseded 15 Nov) | PM, from the evaluation |
| 9 Nov 2026 | A cart with items from several stores splits into one order and one shipment per store | PM |
| 9 Nov 2026 | Documents in English and Arabic | PM |
| 15 Nov 2026 | **(v1.1)** Commit to Django + PostgreSQL; the WooCommerce comparison is dropped (ADR-014) | PM |
| 15 Nov 2026 | **(v1.1)** An Amazon-style shopping experience for the invited stores; open seller sign-up stays in P2 | PM |
| 15 Nov 2026 | **(v1.1)** Server-rendered storefront with page transitions and small interactive parts, built on design tokens (ADR-015, ADR-016) | PM |

The evaluation behind these decisions is in Al-Rashidi Platform: PM Evaluation and Tool

Selection. Glossary Term Meaning here Platform The Al-Rashidi web application and its operator company Store An invited shop that sells on the platform (Al- Rashidi is store 1) Order group What the customer places at checkout; it splits into one order per store Order One store's part of an order group, shipped as one courier shipment COD Cash on delivery, collected by the courier Courier settlement The courier's payout of collected cash, minus its fees, to the store's own account Commission The platform's fee on each store's delivered sales, invoiced monthly

| Term | Meaning here |
| --- | --- |
| Platform | The Al-Rashidi web application and its operator company |
| Store | An invited shop that sells on the platform (Al- Rashidi is store 1) |
| Order group | What the customer places at checkout; it splits into one order per store |
| Order | One store's part of an order group, shipped as one courier shipment |
| COD | Cash on delivery, collected by the courier |
| Courier settlement | The courier's payout of collected cash, minus its fees, to the store's own account |
| Commission | The platform's fee on each store's delivered sales, invoiced monthly |
| Statement | A store's monthly summary: sales, returns, courier fees, commission, net |
| Stock ledger | The append-only record of every stock movement; on-hand stock is its sum |
| Reservation | Stock held for a confirmed online order until it ships or is cancelled |
| POS | Point of sale: the cashier screen in each store, running in a browser |
| ETA | Egyptian Tax Authority; runs e-invoices (B2B) and e-receipts (B2C) |
| PDPL | Egypt's Personal Data Protection Law No. 151 of 2020 |
| MVP, P1, P2 | Release 1 (launch), then the next two releases |
| Proof | The two-week, pass/fail comparison of the two finalist stacks |
