# Product Requirements (PRD)

> Version 1.1, 15 November 2026. Converted from the specification document; the PDFs in `originals/` are version 1.0. Everything that changed on 15 November is listed in [CHANGES-2026-11-15.md](CHANGES-2026-11-15.md) and marked **(v1.1)** below.

## Problem, goals and non-goals

Problem: Al-Rashidi and nearby independent shops sell stationery, books, toys, gifts and household items mainly over the counter. Stock lives in people's heads and on paper. The shops cannot sell online against real stock, they lose sales to chains and online marketplaces, and the owners cannot see margin or stock in time. Product: an Arabic-first platform where a few invited stores sell online from one shop window and run their counter sales on the same stock. A courier delivers and collects the cash.

### Goals for year 1:

1. Customers can find and order any listed product in Arabic on a phone and pay cash on delivery.

2. Every store's online and counter sales draw from one live stock, so nothing is sold twice.

3. Each store gets a correct monthly statement: sales, returns, courier fees, commission, net.

4. The platform covers its running costs from commission within 6 months of launch (target to confirm).

5. Running costs stay under 30 USD a month at launch.

### Non-goals for year 1:

card or wallet payments open seller sign-up native mobile apps loyalty points full double-entry accounting inside the platform AI features for customers the platform holding customers' money

Users and their main needs

| User | Main needs | Device |
| --- | --- | --- |
| Customer | Find items in Arabic, see real availability and the full price with delivery, order with cash on delivery, track and return easily | Mid-range Android phone, 4G |
| Store cashier | Fast sales on the same stock, receipts, refunds, drawer count; keeps working when the internet drops | Tablet or PC browser, barcode scanner, receipt printer |
| Store staff (picker) | Clear list of orders to pack, courier labels, pickup schedule | Tablet or PC |
| Store manager or owner | Products, prices, stock counts, purchases, low-stock alerts, daily sales, monthly statement | Phone and PC |
| Platform admin | Invite and set up stores, set commission, approve products, handle disputes, run statements | PC |
| Platform owner and partners | Orders, revenue, commission earned, costs, store performance | Phone |
| Accountant | Statements and exports that tie to courier settlements and tax filings | PC |

### Scope by release

The MVP is everything needed for Al-Rashidi plus one store to sell online and at the counter, with correct statements. P1 and P2 come only after their gates (see Plan).

| Area | MVP (launch) | P1 (after 3 months live) | P2 (after 6 to 12 months) |
| --- | --- | --- | --- |
| Stores | 2 to 10 invited stores, set up by admin | Store self-service settings | Open seller sign-up with verification |
| Catalog | 3,000+ products, CSV import per store, variants, Arabic and English names, categories, images | Bulk price updates, barcode labels | Shared master catalog across stores |
| Search | Arabic-aware search with spelling normalization; search suggestions while typing **(v1.1, moved from P1 as a Should)** | Synonyms | Semantic search (measured against plain search first) |
| Checkout | Guest checkout, phone OTP, zones and delivery fees, one coupon type, split per store | Saved addresses, customer accounts | Loyalty points |
| Payment | Cash on delivery through the courier | Card payments via a licensed gateway (e.g. Paymob) | Wallet only through a licensed provider |
| Delivery | One courier (e.g. Bosta) with API, labels, tracking, returns | Second courier and per-zone choice | Same-day local delivery option |
| POS | Browser POS per store, offline queue, receipts, refunds, drawer | Barcode label printing, multiple counters | E-receipts for stores named by ETA |
| Stock | Ledger, reservations, counts with approval, purchase receipts, low- stock alerts | Purchase orders to suppliers | Reorder suggestions |
| Money | Commission, monthly statements, courier settlement matching, exports | Commission invoices as ETA e-invoices if required | Automated payouts via a licensed provider |
| Messages | Order SMS or WhatsApp: confirmed, shipped, delivered | Owner daily summary | Customer chat assistant |
| Shopping experience **(v1.1)** | Page transitions, cart drawer grouped per store, photo gallery, loading and empty states, within the motion and speed budgets | Ratings and reviews, wishlist, recently viewed, more from this store | Personalised shelves |
| Reports | Daily sales, stock valuation, statement, low stock | Margin per product | Store benchmarking |

## Key journeys

In an online order, the cash flows from the customer to the courier, then straight to the store. The platform touches only data and the commission invoice. online order journey · 4 parties, 9 steps

### Counter (POS) sale:

1. The cashier scans items. The POS checks stock from its local copy.

2. The customer pays cash. The POS prints a receipt and records the sale; offline sales wait in a queue.

3. The sale posts to the stock ledger. Online availability updates within a minute.

4. At closing, the cashier counts the drawer. The system shows the variance.

### Return of an online order:

1. The customer asks for a return within 14 days, from the order link or by phone.

2. The store approves it. The platform books a courier return pickup.

3. The store inspects the item, then restocks it or writes it off.

4. The refund is recorded against the order and appears on the store's statement.

### Monthly statement:

1. On the 1st, the platform builds each store's statement for the previous month: delivered sales, returns, delivery fees, commission, net.

2. The store's courier settlement report is matched line by line. Any difference is flagged.

3. The store manager reviews and accepts the statement. The commission invoice is issued.

## Business rules

These rules drive the code. Values marked to confirm are placeholders until the store contracts are signed.

| ID | Rule |
| --- | --- |
| BR-01 | Each product belongs to exactly one store. Each store sets its own prices and stock. |
| BR-02 | Prices are shown in EGP and include VAT where the store is VAT-registered. The platform never changes a store's price. |
| BR-03 | A checkout with items from several stores creates one order group and one order per store. Each order ships separately with its own delivery fee, all shown before the customer confirms. |
| BR-04 | The delivery fee comes from the courier's zone tariff and is charged to the customer per store shipment. A free-delivery threshold is a store setting (to confirm). |
| BR-05 | Commission = store commission rate x delivered item value. Delivery fees, cancelled orders and returned items are excluded. Default rate to confirm, set per store by contract. |
| BR-06 | Counter (POS) sales carry no commission in year 1 (to confirm). They still move the shared stock. |
| BR-07 | Cash on delivery settles from the courier to each store's own courier account. The platform invoices commission monthly and never holds customers' money. |
| BR-08 | Returns: a customer may return within 14 days of receipt without a reason, and within 30 days if the item is defective. Books, newspapers and magazines may be excluded from no-reason returns (Law 181/2018 as described by Al-Ahram). The lawyer confirms the wording and who pays return shipping. |
| BR-09 | A refund for a delivered online order is paid by the store, through the courier's return flow or in cash at the counter, and recorded against that order. |
| BR-10 | Failed delivery (customer refuses or is unreachable): the courier returns the parcel, stock goes back on hand after the store checks it, and the return fee is charged to store or platform, to confirm. |
| BR-11 | One coupon per order group, with an expiry and a usage limit. The coupon names who funds the discount (store or platform). Coupons never stack. |
| BR-12 | A customer can cancel free of charge until the store hands the parcel to the courier. |
| BR-13 | Stock below the store's reorder level triggers an alert to the store manager. |
| BR-14 | Only a store manager can approve stock-count differences and price changes; every such change is audited. |

## Success metrics and launch gates

| Metric | Target | Measured from |
| --- | --- | --- |
| Oversold orders | 0 | Stock ledger vs. orders |
| Statement accuracy | 0 EGP unexplained difference per store per month | Statement vs. courier settlement report |
| Stock accuracy on cycle counts | 98% or better of counted items match | Count records |
| First-attempt delivery success | Baseline in the pilot, then improve | Courier status data |
| Return rate | Baseline in the pilot | Returns vs. delivered orders |
| Mobile page speed (category, product) | Under 3 seconds to usable on 4G | Lighthouse on a mid-range phone |
| Monthly running cost | Under 30 USD | Invoices |
| Commission vs. running cost | Commission covers running cost by month 6 (to confirm) | Statements, invoices |
| Restore drill | Passes every month | Runbook log |

### Launch gates:

all must-pass tests in the Test plan pass on staging a real order, a real return and a monthly statement succeed in the pilot the restore drill passed in the last 30 days partnership terms and store contracts are signed legal items (PDPL licence path, return policy) are answered Assumptions and open product decisions Assumptions: Every store has internet at the counter most of the day, and a tablet or PC. Every store can open its own business account with the chosen courier. Customers accept separate parcels and delivery fees per store. Each store provides a product file with price, cost and stock. Open decisions: Default commission rate, and whether it varies by category: PM with owners, before store contracts Who pays the return fee for failed deliveries: store or platform

### Free-delivery threshold, if any, per store

Whether counter sales carry commission (default: no) Commission cover target and the date to review it
