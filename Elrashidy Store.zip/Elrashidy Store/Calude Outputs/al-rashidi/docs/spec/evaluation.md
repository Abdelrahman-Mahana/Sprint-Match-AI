# Al-Rashidi Platform: PM Evaluation and Tool

> Background only (8 November 2026). Its recommendation to compare two stacks was closed by ADR-014.

Selection Nov 8, 2026 · @Abdulrahman Verdict The project is workable, but it should be built lean and not on ERPNext. The recommended default is one web application on PostgreSQL that holds every store's catalog, stock and orders. Each store gets a browser-based cashier screen (POS), and a courier such as Bosta delivers and collects the cash. A Django codebase is the suggested starting point. Score: 4.05 out of 5, against 3.55 for the nearest challenger. The ERPNext plan (verdict v1.0, 3 November 2026) answered a different project, so it no longer fits:

|  | ERPNext plan assumed | Confirmed scope now |
| --- | --- | --- |
| Sellers | One shop; outside sellers in phase 2 | A few invited stores from the start |
| Catalog | 30 to 60 items | 3,000 or more products |
| Delivery and cash | Own drivers, driver cash ledger | Courier company collects cash on delivery |
| In-store | Al-Rashidi POS only | POS for every store |

### Three facts tip the choice away from ERPNext:

1. Its storefront serves a single seller, so the multi-store layer would be custom work anyway. 2. It is heavy for the budget. Frappe's own database guidance starts at 8 GB RAM (ZimaSpace summary of Frappe guidance). Hetzner's cheap 8 GB plan was marked unavailable in September 2026. The orderable 8 GB plan cost EUR 35.99 a month, above the 30 USD ceiling (Schmalbach, Sept 2026). 3. The courier removes the plan's hardest custom part, the driver cash ledger. Don't sign off on the stack yet. Hold a two-week proof first: the Django build against WooCommerce + Dokan + wePOS, the fast challenger. Run the same pass/fail tests on both (section 6). If WooCommerce passes all of them, it is the cheaper road and should win.

## Confirmed scope

This evaluation judges a small multi-store platform in Egypt that can open up later. These are the PM's answers of 8 November 2026:

| Question | Answer |
| --- | --- |
| What it is | Marketplace: Al-Rashidi plus other stores, with commissions |
| How stores join (year 1) | A few invited stores (about 2 to 10), set up by the admin; open sign-up later |
| Catalog at launch | About 3,000 products or more |
| Delivery and cash | A courier company delivers and collects cash on delivery |
| In-store | POS, stock counts and purchasing for every store |
| Builder | Can work in any technology; wants the lightest system that does the job |
| Market, language | Egypt, EGP, Arabic first |
| Running-cost ceiling | Under 30 USD a month (from the existing plan) |

Out of scope for year 1: card payments, an in-app wallet, native mobile apps, open seller sign-up and AI features for customers.

## Review of the existing documents

The main problem is the process, not one tool. The stack changed four times with no fixed test:

1. A weighted matrix: Django 4.13, NestJS 3.98, Odoo 3.73.

2. Next.js + NestJS + Supabase or Neon.

3. Django from scratch.

4. ERPNext. There was also an earlier idea of a separate offline Windows cashier program. Each switch followed a new argument, not a new fact. The fix is a decision record with agreed criteria and proof tests (section 6).

| Item | Finding | Action |
| --- | --- | --- |
| ERPNext verdict v1.0 | Its method is sound: a time-boxed trial with go/no-go gates. It was written for one shop with its own drivers. | Keep the method; replace the conclusion |
| Project name vs PRD scope | The PRD sells own stock first, but the schema already has seller fields from day one | Align the PRD to the confirmed scope |
| Product count | Plan says 30 to 60 items; colleague assumed about 3,000; PM confirms 3,000+ | Plan for 3,000+ with CSV import per store |
| Latest branded PRD drafts | They describe a Saudi services marketplace: 61 screens, 20 weeks. That is the Wesal/Khawini content under the Al-Rashidi logo, with a placeholder table ("A / B, One") | Discard |
| Brand board | Horizontal logo misspelled «يﺪﻴﺳﺮﻟا»; Saudi phone (+966), .sa email and س.ر prices | Fix before any print or launch |
| Brand tokens | Two palettes (navy #071D36 vs #082D4B) and two font sets (Cairo/IBM Plex vs GE SS Two/Poppins) | Pick one set in a single design-token file |
| Colleague's review (Arabic) | Right on the key question (one shop or marketplace) and on cost risk; recommends WooCommerce to test or Django to build | Adopted as the challenger and the default |
| Partnership terms | The developer is paid by a share of sales, with no written terms on code ownership, server costs or exit | Sign before any build work |
| Duplicate files | files.zip and files_11.zip hold the same Owner Overview and Team PRD | Keep one copy in the repository docs folder |

### Options compared

Custom Django ranks first at 4.05 of 5, and WooCommerce + Dokan + wePOS second at 3.55. Five stacks were scored on 11 weighted criteria in the attached scoring sheet, where weights and scores can be changed. The scores are engineering judgment, to be replaced by proof-test results.

| Option | Score /5 | Best at | Main weakness for this scope |
| --- | --- | --- | --- |
| A. Django + PostgreSQL (custom) | 4.05 | Control, stock correctness, Arabic search, one small server | Most to build: POS screen, statements, courier link |
| B. WooCommerce + Dokan + wePOS | 3.55 | Fastest launch; every Dokan vendor gets its own free POS with private data | Plugin sprawl; overselling and offline POS unproven; weak Arabic search |
| E. Odoo Community + add-ons | 3.40 | Mature POS and stock | Marketplace, marketplace POS (USD 378) and Bosta are paid add-ons; heavy server |
| D. ERPNext multi- company | 3.30 | Best in-store side: POS, stock, accounting, ETA apps | Single-seller storefront; heavy for the budget |
| C. Medusa v2 + Mercur | 3.25 | Marketplace base: vendor panel, commissions, order splitting | Payouts built on Stripe Connect; no POS |

Two stacks fail the budget outright. ERPNext and Odoo need an 8 GB server, about 50

USD a month at orderable Hetzner prices. The three lean options fit a 4 GB server at about 28 USD, close to the 30 USD ceiling. Rejected without scoring: Shopify: monthly fees and data on the vendor's servers; no shared stock with an in- house POS. Firebase: a poor fit for stock and money records. Supabase as the whole backend: it pushes business logic into database functions. It remains a valid managed PostgreSQL host for option A.

## Recommended architecture

One application, one database and one small server serve every store. The only custom work is the core modules (highlighted). Everything else is a standard part or an outside service. recommended architecture · one server, four outside services Stores are separated by a store id on every row, checked on every request. This is enough for 2 to 10 invited stores. Open sign-up later needs only an onboarding flow, not a rebuild.

### Stock changes only through ledger entries inside database transactions, whether

from online orders, POS sales, returns or counts. This is what stops the last unit being sold twice. The POS is a web page on a tablet, with a local queue for an hour of lost signal. No app-store work is needed.

### Suggested parts for option A:

Django with Django REST Framework PostgreSQL with Arabic text normalization and trigram search

### server-rendered storefront pages for speed and search engines

a small offline-capable POS front end Docker Compose For option B, the same picture holds: WordPress + WooCommerce + Dokan + wePOS replaces the core modules, with MySQL instead of PostgreSQL. How to make sure of the tools You can only be sure of a tool by watching it pass your own tests on your own data. A feature list or a blog comparison is not enough. Use this method for this decision and for any later tool change: 1. Freeze the must-haves from the confirmed scope (section 2). Anything not on the list cannot justify a switch. 2. Shortlist two finalists from the scoring sheet: A (Django) and B (WooCommerce + Dokan + wePOS). 3. Run the same proof tests on both, time-boxed to two weeks, with the same 3,000- product file and two test stores. Record Pass, Fail or Not run in the sheet. 4. Decide by rule: Any must-pass Fail disqualifies an option. If both pass, take the one with less build effort and lower running cost, so WooCommerce wins a tie. If both fail, test Medusa (C) next. 5. Write a one-page decision record with: the choice and the test results what it costs what event would reopen it, such as moving to open seller sign-up or a store being named in an e-receipt decision 6. Check vendor claims at the source. Read the code or the official docs and pin versions. Treat marketing pages and blog posts as leads, not facts. Must-pass proof tests (full list with pass criteria in the sheet):

| # | Test | Pass when |
| --- | --- | --- |
| 1 | Import 3,000 products for 2 stores | All rows in; a re-import updates and never duplicates |
| 2 | Store isolation | Store 2 staff cannot see or edit anything of Store 1 |
| 3 | Last unit sold online and at the POS at the same moment | One sale succeeds; stock ends at 0, never -1 |
| 4 | 20 real Arabic searches with spelling variants | 18 or more find the right item first |
| 5 | Mobile speed on a mid-range phone, 4G | Category and product pages usable in under 3 seconds |
| 6 | Cart with items from 2 stores | One order and one courier shipment per store, fees shown before confirming |
| 7 | Courier round trip in the courier's staging system | Status and cash collected match without hand entry |
| 8 | Return after delivery | Stock and the store's statement are correct |
| 9 | POS day: 50 sales, 2 refunds, 1 hour offline | No lost sales; drawer variance shown; sync on reconnect |
| 10 | Monthly commission statement | Matches a hand calculation to the piaster |
| 11 | Restore last night's backup on a clean server | Running with yesterday's orders within 4 hours |

### Money flow, courier, tax and legal points

Recommended: the platform never holds customers' money in year 1. Each store keeps its own courier business account, so cash on delivery settles straight to that store. The platform then invoices each store its commission monthly. This also keeps the platform out of payment-facilitator rules: collecting payments on behalf of merchants is a Central Bank of Egypt regulated activity (IBA summary, 2025 licensing rules). Ask the lawyer whether a central courier account would trigger them. Courier integration is routine. Bosta's API covers delivery, cash collection, returns and exchanges. It reports per-shipment cash details: COD amount, Bosta fees and deposit date (Bosta Laravel package, ShipBridge Bosta driver). These are community packages, so confirm against Bosta's own API documentation and get a staging key. Multi-store cart: an order splits into one order and one shipment per store. The customer sees each store's delivery fee before confirming. The alternative is a cart limited to one store at a time, which is simpler for year 1. The PM should choose.

E-receipts depend on the store, not on revenue. Egypt's B2C e-receipt duty applies

to taxpayers named in ETA decisions, with no turnover threshold. Each store checks its own tax number in ETA's lookup. A central system serving several outlets must register each outlet as a separate POS. Receipts issued offline must be submitted within 24 hours (Egypt e-receipt guide, Aug 2026). Until a store is named, its POS issues ordinary receipts. Commission invoices: if the platform's company is VAT-registered, its commission invoices to stores are B2B documents under ETA e-invoicing (VATupdate briefing). This is for the accountant to confirm. Contracts with each store: commission rate, returns and who pays for failed deliveries, payment terms for the commission, product liability and data handling. Plan, effort and running cost The build takes about 6 to 11 weeks on WooCommerce, or 18 to 28 weeks on Django, at 20 hours a week. Running costs are about 28 USD a month on either stack. roadmap · 4 phases, 3 gates Four phases, each closed by a gate. The build starts only after the proof picks the stack.

| Path | MVP build (rough hours) | At 20 h/week | Monthly running cost |
| --- | --- | --- | --- |
| A. Django + PostgreSQL | 350 to 550 | 18 to 28 weeks | about EUR 24 (28 USD) on a 4 GB server |
| B. WooCommerce + Dokan + wePOS | 120 to 220 | 6 to 11 weeks | about EUR 24 (28 USD), plus any Pro licences |

The hours are judgment estimates for one builder using an AI coding assistant. They are

lower than the earlier 525 to 925 hours because the courier removes the driver cash ledger. Stores also keep their own books in year 1: the platform produces per-store statements and exports, not full double-entry accounting. Running cost uses Hetzner's orderable 4 GB plan at EUR 19.99 including IPv4, plus 20% for backups. The cheaper CX plans (EUR 5.99) were marked unavailable in September 2026 (Schmalbach). If they come back, the cost drops to about EUR 7. The total leaves only about 2 USD under the ceiling, so check prices on the day you order. Excluded: domain, SMS/WhatsApp, and courier fees, which come out of each shipment's cash. Risks The biggest risk is commercial, not technical. A developer paid only by a share of sales may spend months building before order volume covers the work.

| Risk | Likelihood, impact | Mitigation |
| --- | --- | --- |
| Order volume never covers build time and running costs | High, high | Run the proof before the build; launch with Al-Rashidi plus one store; set a minimum monthly fee or cost cover in the partnership terms |
| Stack switched again mid-build | High, high | Decision record with reopen triggers; no switch without a failed proof test |
| Ownership dispute over code, data or brand | Medium, high | Written agreement before any build work |
| Overselling between POS and online | Medium, medium | Proof test 3; stock moves only inside database transactions |
| Plugin breakage after updates (path B) | Medium, medium | Staging site, pinned versions, monthly update window |
| Server price or availability changes | High, medium | Docker setup that moves between providers; nightly off-site backup; budget check before ordering |
| A store is named in an ETA e- receipt decision | Medium, high | Each store checks the ETA lookup now; keep a certified e-receipt POS for that store until the platform supports it |
| Courier cash not reconciled to orders | Medium, high | Proof test 7; weekly match of courier statements to orders |
| Platform holds third-party money by accident | Low, high | COD settles to each store's own courier account; lawyer confirms |
| Brand errors reach print (misspelled logo, Saudi details) | Medium, medium | Fix the board; one approved token file |

### Decisions for the PM and open items

Seven decisions block the proof. The last three items need outside answers. Approve the two finalists (A and B) and the two-week proof Partnership terms in writing: pay or share, who funds running costs, code and data ownership, exit Commission model and a draft contract for invited stores Multi-store cart: split shipments per store, or one store per cart in year 1 Accounting scope: per-store statements and exports in year 1, or full bookkeeping inside the platform Pick the courier and get staging API keys (Bosta and one alternative) One brand token file: palette, fonts, corrected logo Accountant: does each store appear in ETA's e-receipt obligation list? Is the platform company VAT-registered? Lawyer: is a central courier account collecting COD a regulated payment activity? Rules on customer data storage and retention Hetzner (or alternative): which 4 GB plan is orderable on the day, and its price Sources Checked on 8 November 2026. Vendor and blog pages are leads, so confirm each fact at the source on the day you rely on it. Uploaded material: ERPNext verdict v1.0 (3 Nov 2026), Brand and UI/UX guidelines, colleague's review (Arabic), three chat archives, Owner Overview, Team PRD, Owner and Developer Packs, brand boards Hetzner cheap cloud tier unavailable, Sept 2026 (Schmalbach) ERPNext hardware requirements, summary of Frappe guidance (ZimaSpace)

### wePOS now supports Dokan (Dokan blog)

wePOS readme Dokan on GitHub Mercur on GitHub Medusa marketplace recipe Odoo Marketplace POS Extension, v19 (Webkul) Odoo Egypt localization guide 2026 (ECOSIRE) Laravel Bosta package ShipBridge Bosta driver Egypt e-receipt compliance guide, Aug 2026 VATupdate: e-invoicing and e-reporting in Egypt IBA: Egyptian Central Bank regulates payment service providers Business Today Egypt: CBE licensing rules for payment providers, June 2025 Scoring sheet with weights, proof tests and costs: AlRashidi_Tool_Selection_Scoring.xlsx (sent with this doc)
