# Test Plan

> Version 1.1, 15 November 2026. Converted from the specification document; the PDFs in `originals/` are version 1.0. Everything that changed on 15 November is listed in [CHANGES-2026-11-15.md](CHANGES-2026-11-15.md) and marked **(v1.1)** below.

Test strategy and tools Most tests are automated and run on every push. People test what machines cannot judge: Arabic wording, layout on real phones, receipt printing, and whether a statement makes sense to a store owner.

| Level | What it proves | Tool | When |
| --- | --- | --- | --- |
| Unit | Rules: commission, fees, normalization, state transitions | pytest, pytest-django | Every push |
| Integration | Database rules: ledger, locking, store scoping, idempotency | pytest with a real PostgreSQL in CI | Every push |
| Contract | Courier and messaging adapters against recorded responses | pytest with recorded fixtures; courier staging weekly | Every push; weekly live |
| End-to-end | Customer checkout, POS sale, return, statement in a browser | Playwright (Chromium, mobile viewport, RTL) | Before each release |
| Concurrency | Last unit sold online and at the POS at once | A pytest that fires parallel requests | Every push |
| Load | Capacity and speed targets | k6 against staging | Before launch and before September |
| Security | Common web flaws, dependency issues | OWASP ZAP baseline scan, pip-audit, ASVS checklist | Monthly and before launch |
| Accessibility | Contrast, labels, focus | axe in Playwright, plus a manual check | Before each release |
| User acceptance | Real staff complete real tasks | Scripted sessions with each role | End of phases 5 to 8 and the pilot |

### Proof and acceptance tests

The first 11 tests are the proof. They run on both finalist stacks and decide ADR-001. All 20 must pass on staging before launch.

| Test | Steps | Pass when | Proves |
| --- | --- | --- | --- |
| AT-01 Import | Import 3,000 products for 2 stores, then re-import with 50 price changes | All rows in; 50 updated; 0 duplicates; error report for bad rows | FR-CAT-03 |
| AT-02 Isolation | Log in as store 2 staff; open every screen and API for a store 1 record | Every attempt returns not found | FR-SEC-02 |
| AT-03 Last unit | Stock 1; fire an online checkout and a POS sale at the same moment, 20 times | Exactly one sale each time; stock 0, never -1 | FR-STK-03 |
| AT-04 Arabic search | Run the 20-query spelling- variant set | 18 or more correct first results | FR-SRC-01, 02 |
| AT-05 Mobile speed | **(v1.1)** Home, category and product pages on a mid-range Android, 4G throttled | Largest content in 2.5 s or less; tap response 200 ms or less; layout shift 0.1 or less; page weight inside the budget | NFR-PERF-01, NFR-PERF-03 |
| AT-06 Split cart | Cart with items from 2 stores; check out | 1 order group, 2 orders, 2 shipments, fees shown before confirm | FR-CHK-03 |
| AT-07 Courier round trip | Create shipment in courier staging; receive webhooks; import settlement | Statuses and cash match without hand entry; forged webhook rejected | FR-SHP-01, 02, 04 |
| AT-08 Return | Deliver, request return, courier pickup, inspect as sellable and as damaged | Stock and statement correct in both cases | FR-RET-01 to 03 |
| AT-09 POS day | 50 sales, 2 refunds, 1 hour offline mid-day, close drawer | No lost or doubled sales; variance shown | FR-POS-01 to 05 |
| AT-10 Statement | A month of mixed orders for 2 stores | Matches a hand calculation to the piaster | FR-FIN-01, 02 |
| AT-11 Restore | Restore last night's backup on a clean server | Running with yesterday's orders within 4 hours | NFR-REC-01 |
| AT-12 Idempotency | Double-tap Place order; replay the request | One order group | FR-CHK-06 |
| AT-13 OTP limits | Wrong code 5 times; resend 5 times | Locked for 1 hour; no order | FR-CHK-02 |
| AT-14 Cancel | Cancel before handover; try after handover | First succeeds and releases stock; second refused | FR-ORD-03 |
| AT-15 Count approval | Cashier submits a count; manager approves one difference, rejects another | Only the approved difference posts, with reason | FR-STK-04 |
| AT-16 Low stock | Sell down to the reorder level | One alert to the manager | FR-STK-06 |
| AT-17 Messages | Move an order through all states; break the SMS provider for 10 minutes | All messages arrive, retried, logged once | FR-NTF-01 |
| AT-18 Consent | Customer without opt-in in a marketing send | Not messaged | FR-NTF-02 |
| AT-19 2FA | Manager login without the second factor | Refused | FR-SEC-01 |
| AT-20 Audit | Change a price, approve a count, record a refund | Each appears in the audit log with old and new values | NFR-AUD-01 |
| AT-21 Motion and fallback | **(v1.1)** Browse and check out three ways: normally, with reduced motion on, and with scripts off | All three complete an order; no animation over 320 ms; none with reduced motion | NFR-UX-01, FR-UX-01, FR-UX-02 |

### Test data, environments and release checklist

Test data: a 3,000-product file per test store, with Arabic names in mixed spellings 20 real search queries collected from Al-Rashidi staff 10 sample addresses across delivery zones a month of generated orders with known totals for AT-10 No real customer data in local or CI environments. Staging copies of production mask names and phones.

Environments: tests run in CI against a throwaway PostgreSQL. End-to-end, load and

courier tests run on staging with courier staging keys. Never point load tests at production. Release checklist: All automated tests green in CI Migrations reviewed and backward compatible Changelog written in plain Arabic and English for store staff Deployed to staging; smoke test passed Relevant acceptance tests re-run on staging Backup taken just before production deploy Deployed to production; smoke test passed Error rate and queue length watched for 30 minutes Rollback image noted
