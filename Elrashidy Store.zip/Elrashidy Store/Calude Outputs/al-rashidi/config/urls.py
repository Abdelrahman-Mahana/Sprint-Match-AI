from django.conf.urls.i18n import i18n_patterns
from django.contrib import admin
from django.urls import include, path

from apps.core.views import healthz

urlpatterns = [
    path("healthz", healthz, name="healthz"),
    path("i18n/", include("django.conf.urls.i18n")),
    # Versioned JSON API for the POS and integrations (TDD, API design).
    path("api/v1/", include(("config.api_v1", "api"), namespace="v1")),
]

urlpatterns += i18n_patterns(
    path("backoffice/", admin.site.urls),
    path("", include("storefront.urls")),
    prefix_default_language=False,
)
