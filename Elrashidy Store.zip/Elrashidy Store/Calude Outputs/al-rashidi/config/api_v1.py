"""Routes under /api/v1/. Each app adds its own urls module here as it is built."""

from django.urls import URLPattern, URLResolver

urlpatterns: list[URLPattern | URLResolver] = []
