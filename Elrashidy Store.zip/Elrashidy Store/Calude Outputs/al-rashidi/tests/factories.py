"""Small builders for tests. Plain functions, so a test reads top to bottom."""

from itertools import count

from apps.catalog.models import Category, Product, Variant
from apps.stores.models import Store

_seq = count(1)


def make_store(**kwargs: object) -> Store:
    n = next(_seq)
    defaults: dict[str, object] = {
        "name_ar": f"محل {n}",
        "name_en": f"Store {n}",
        "slug": f"store-{n}",
        "status": Store.Status.ACTIVE,
    }
    return Store.objects.create(**(defaults | kwargs))


def make_category(**kwargs: object) -> Category:
    n = next(_seq)
    defaults: dict[str, object] = {"name_ar": f"قسم {n}", "slug": f"category-{n}"}
    return Category.objects.create(**(defaults | kwargs))


def make_product(store: Store, *, price_pt: int = 2500, **kwargs: object) -> Product:
    n = next(_seq)
    defaults: dict[str, object] = {
        "name_ar": f"كراسة {n}",
        "category": kwargs.pop("category", None) or make_category(),
        "status": Product.Status.ACTIVE,
    }
    product = Product.objects.create(store=store, **(defaults | kwargs))
    Variant.objects.create(store=store, product=product, sku=f"SKU-{n}", price_pt=price_pt)
    return product
