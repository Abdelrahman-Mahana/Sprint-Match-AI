"""NFR-PERF-03: the page-weight budget for a first visit, checked on every push."""

import gzip
from pathlib import Path

STATIC = Path(__file__).resolve().parent.parent / "storefront" / "static" / "storefront"
KB = 1024


def _compressed(paths: list[Path]) -> int:
    return sum(len(gzip.compress(path.read_bytes(), 9)) for path in paths)


def test_scripts_stay_under_50_kb_compressed():
    scripts = [*STATIC.glob("vendor/*.js"), *STATIC.glob("js/*.js")]
    assert _compressed(scripts) <= 50 * KB


def test_styles_stay_under_30_kb_compressed():
    assert _compressed(list(STATIC.glob("css/*.css"))) <= 30 * KB


def test_fonts_stay_under_160_kb():
    # woff2 is already compressed, so the file size is the download size.
    assert sum(font.stat().st_size for font in STATIC.glob("fonts/*.woff2")) <= 160 * KB
