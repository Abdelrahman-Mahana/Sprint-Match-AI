# POS client

The offline-capable cashier web app (ADR-006): a progressive web app that keeps the store's
catalog and a queue of sales in IndexedDB and syncs through `/api/v1/pos/`.

Nothing is built here yet. It starts with tasks T-29 to T-31; the design is in
`docs/spec/04_tdd.md` under "POS offline design".
