"""Users, roles, two-factor login and store membership checks.

Traces to: FR-SEC-01, FR-SEC-02 · T-15
"""
