from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    """Staff and admin accounts. Customers check out as guests and verify by phone code.

    A custom user model from the first migration, because swapping it later is painful.
    Store roles live in ``stores.StoreMembership``; platform admins are superusers.
    """

    phone = models.CharField(max_length=20, blank=True)
