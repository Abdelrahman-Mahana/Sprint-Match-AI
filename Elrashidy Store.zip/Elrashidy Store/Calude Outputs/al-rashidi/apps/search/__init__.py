"""Arabic normalization, search index, ranking, filters.

Traces to: FR-SRC-01 to 04 · T-20
"""
