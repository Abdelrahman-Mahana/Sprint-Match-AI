import pytest

from apps.search.normalize import normalize


# The rows of the normalization table in the TDD (Arabic search), one test each.
@pytest.mark.parametrize(
    ("raw", "expected"),
    [
        ("كُرَّاسة", "كراسه"),  # diacritics removed, ta marbuta to ha
        ("كـــراسة", "كراسه"),  # tatweel removed
        ("أقلام", "اقلام"),  # hamza forms to bare alif
        ("إبرة", "ابره"),
        ("آلة", "اله"),
        ("مستشفى", "مستشفي"),  # alif maqsura to ya
        ("١٢", "12"),  # Arabic digits to Latin
        ("  Faber   Castell ", "faber castell"),  # lower-case Latin, trim spaces
    ],
)
def test_normalize(raw, expected):
    assert normalize(raw) == expected


def test_spelling_variants_meet():
    assert normalize("كراسة") == normalize("كراسه") == normalize("كُرّاسة")
