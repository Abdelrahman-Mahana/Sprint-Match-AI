"""Arabic-aware text normalization (FR-SRC-01, TDD: Arabic search).

The same function normalizes stored product names and the customer's query, so that
spelling variants meet in the middle.
"""

import re

_DIACRITICS_AND_TATWEEL = re.compile("[ً-ْٰـ]")
_SPACES = re.compile(r"\s+")
_LETTERS = str.maketrans(
    {
        "أ": "ا",
        "إ": "ا",
        "آ": "ا",
        "ٱ": "ا",
        "ة": "ه",
        "ى": "ي",
    }
)
_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹", "01234567890123456789")


def normalize(text: str) -> str:
    text = _DIACRITICS_AND_TATWEEL.sub("", text)
    text = text.translate(_LETTERS).translate(_DIGITS)
    return _SPACES.sub(" ", text).strip().lower()
