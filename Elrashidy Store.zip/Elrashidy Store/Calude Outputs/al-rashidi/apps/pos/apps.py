from django.apps import AppConfig


class PosConfig(AppConfig):
    name = "apps.pos"
    default_auto_field = "django.db.models.BigAutoField"
