"""POS sync API, drawer sessions, receipts.

Traces to: FR-POS-01 to 06 · T-29 to T-31
"""
