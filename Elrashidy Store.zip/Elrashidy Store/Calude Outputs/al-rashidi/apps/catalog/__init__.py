"""Product, variant, category, image, CSV import.

Traces to: FR-CAT-01 to 06 · T-17 to T-19
"""
