from django.contrib import admin

from .models import Category, Product, Variant


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ["name_ar", "name_en", "parent"]
    prepopulated_fields = {"slug": ["name_en"]}


class VariantInline(admin.TabularInline):
    model = Variant
    extra = 0


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ["name_ar", "store", "category", "status"]
    list_filter = ["store", "status", "category"]
    search_fields = ["name_ar", "name_en"]
    inlines = [VariantInline]
