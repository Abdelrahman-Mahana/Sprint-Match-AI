"""Service layer for catalog.

Other apps call these functions and never import this app's models directly
(see docs/conventions.md, rule 1).
"""

from django.db.models import Min, Prefetch, QuerySet

from apps.stores.services import STORE_ACTIVE

from .models import Category, Product, Variant


def _public_products() -> QuerySet[Product]:
    """Products any shopper may see: active, from an active store.

    The shop shows every store's products, so this is the one read that does not go
    through ``for_store``. Back-office reads always do.
    """
    return (
        Product.objects.filter(status=Product.Status.ACTIVE, store__status=STORE_ACTIVE)
        .select_related("store", "category")
        .annotate(from_price_pt=Min("variants__price_pt"))
        .filter(from_price_pt__isnull=False)
    )


def top_categories() -> list[Category]:
    return list(Category.objects.filter(parent__isnull=True))


def newest_products(*, limit: int, offset: int = 0) -> list[Product]:
    return list(_public_products().order_by("-id")[offset : offset + limit])


def public_product(product_id: int) -> Product | None:
    return (
        _public_products()
        .prefetch_related(Prefetch("variants", queryset=Variant.objects.order_by("price_pt")))
        .filter(pk=product_id)
        .first()
    )
