"""Catalog models. These are the reference example of a store-owned model: copy the pattern.

Only the fields the TDD data model names are here. Images, CSV import and admin approval
arrive with tasks T-17 to T-19.
"""

from typing import Any

from django.core.exceptions import ValidationError
from django.db import models
from django.db.models import Q

from apps.core.models import StoreScopedModel, TimeStampedModel


class Category(TimeStampedModel):
    """Platform-wide category tree, shared by every store."""

    name_ar = models.CharField(max_length=120)
    name_en = models.CharField(max_length=120, blank=True)
    slug = models.SlugField(unique=True, allow_unicode=True)
    parent = models.ForeignKey(
        "self", null=True, blank=True, on_delete=models.PROTECT, related_name="children"
    )

    class Meta:
        verbose_name_plural = "categories"
        ordering = ["name_ar"]

    def __str__(self) -> str:
        return self.name_ar


class Product(StoreScopedModel, TimeStampedModel):
    """One store's product (BR-01, FR-CAT-01). Sold through its variants."""

    class Status(models.TextChoices):
        DRAFT = "draft", "Draft"
        ACTIVE = "active", "Active"
        HIDDEN = "hidden", "Hidden"

    name_ar = models.CharField(max_length=200)
    name_en = models.CharField(max_length=200, blank=True)
    description_ar = models.TextField(blank=True)
    description_en = models.TextField(blank=True)
    category = models.ForeignKey(Category, on_delete=models.PROTECT, related_name="products")
    status = models.CharField(max_length=8, choices=Status, default=Status.DRAFT)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.CheckConstraint(condition=~Q(name_ar=""), name="product_name_ar_required"),
        ]

    def __str__(self) -> str:
        return self.name_ar


class Variant(StoreScopedModel, TimeStampedModel):
    """A sellable unit with its own SKU, price and stock (FR-CAT-02)."""

    product = models.ForeignKey(Product, on_delete=models.CASCADE, related_name="variants")
    sku = models.CharField(max_length=64)
    barcode = models.CharField(max_length=64, blank=True)
    price_pt = models.PositiveBigIntegerField(help_text="Selling price in piasters")
    cost_pt = models.PositiveBigIntegerField(default=0, help_text="Unit cost in piasters")
    eta_item_code = models.CharField(max_length=64, blank=True)
    reorder_level = models.PositiveIntegerField(default=0)

    class Meta:
        ordering = ["id"]
        constraints = [
            models.UniqueConstraint(fields=["store", "sku"], name="variant_sku_unique_per_store"),
        ]

    def __str__(self) -> str:
        return self.sku

    def clean(self) -> None:
        if self.product_id and self.store_id != self.product.store_id:
            raise ValidationError("A variant belongs to the same store as its product")

    def save(self, *args: Any, **kwargs: Any) -> None:
        self.clean()
        super().save(*args, **kwargs)
