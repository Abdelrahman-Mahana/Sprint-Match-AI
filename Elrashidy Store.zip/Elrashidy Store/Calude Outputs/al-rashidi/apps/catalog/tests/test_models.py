import pytest
from django.core.exceptions import ValidationError
from django.db import IntegrityError, transaction

from apps.catalog.models import Product, Variant
from tests.factories import make_category, make_product, make_store

pytestmark = pytest.mark.django_db


def test_product_needs_a_store_and_an_arabic_name():
    """FR-CAT-01: a product without a store or an Arabic name cannot be saved."""
    category = make_category()
    with pytest.raises(IntegrityError), transaction.atomic():
        Product.objects.create(name_ar="كراسة", category=category)
    with pytest.raises(IntegrityError), transaction.atomic():
        Product.objects.create(store=make_store(), name_ar="", category=category)


def test_for_store_returns_only_that_stores_rows():
    """FR-SEC-02: the store-scoped manager is the wall between stores."""
    store_1, store_2 = make_store(), make_store()
    mine = make_product(store_1)
    make_product(store_2)
    assert list(Product.objects.for_store(store_1)) == [mine]
    assert Variant.objects.for_store(store_2).count() == 1


def test_sku_is_unique_inside_a_store_only():
    store_1, store_2 = make_store(), make_store()
    product_1, product_2 = make_product(store_1), make_product(store_2)
    Variant.objects.create(store=store_1, product=product_1, sku="PEN-01", price_pt=500)
    Variant.objects.create(store=store_2, product=product_2, sku="PEN-01", price_pt=600)
    with pytest.raises(IntegrityError), transaction.atomic():
        Variant.objects.create(store=store_1, product=product_1, sku="PEN-01", price_pt=700)


def test_variant_cannot_join_another_stores_product():
    product = make_product(make_store())
    with pytest.raises(ValidationError):
        Variant.objects.create(store=make_store(), product=product, sku="X", price_pt=100)
