"""Fill a local database with two stores and a few shelves of products.

    python manage.py seed_demo

For local development and design review only. It refuses to run outside DEBUG.
"""

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.catalog.models import Category, Product, Variant
from apps.core.money import to_piasters
from apps.stores.models import Store

CATEGORIES = [
    ("books", "كتب وكراسات", "Books and notebooks"),
    ("stationery", "أدوات مكتبية", "Stationery"),
    ("toys", "ألعاب وهدايا", "Toys and gifts"),
    ("accessories", "إكسسوارات", "Accessories"),
    ("printing", "طباعة وتصوير", "Printing and photocopying"),
]
STORES = [
    ("al-rashidi", "الرشيدي", "Al-Rashidi"),
    ("demo-store-2", "مكتبة النور", "Al-Nour Bookshop"),
]
PRODUCTS = [
    ("books", "كراسة سلك 100 ورقة مسطر", "Spiral notebook, 100 ruled sheets", "45"),
    ("books", "كشكول 200 ورقة غلاف مقوى", "Hardcover notebook, 200 sheets", "85"),
    ("books", "كراسة رسم A4", "A4 sketch pad", "35"),
    ("stationery", "قلم رصاص HB دستة", "HB pencils, box of 12", "30"),
    ("stationery", "قلم جاف أزرق", "Blue ballpoint pen", "7.50"),
    ("stationery", "علبة ألوان خشب 24 لون", "Colouring pencils, 24 colours", "120"),
    ("stationery", "مقلمة قماش", "Fabric pencil case", "95"),
    ("stationery", "مسطرة 30 سم", "30 cm ruler", "12"),
    ("toys", "مكعبات بناء 100 قطعة", "Building blocks, 100 pieces", "260"),
    ("toys", "بازل 500 قطعة", "500-piece puzzle", "175"),
    ("toys", "علبة صلصال 12 لون", "Modelling clay, 12 colours", "60"),
    ("accessories", "شنطة مدرسة ظهر", "School backpack", "480"),
    ("accessories", "زمزمية مياه 500 مل", "Water bottle, 500 ml", "110"),
    ("accessories", "لانش بوكس", "Lunch box", "140"),
]


class Command(BaseCommand):
    help = "Create demo stores, categories and products for local development."

    @transaction.atomic
    def handle(self, *args: object, **options: object) -> None:
        if not settings.DEBUG:
            raise CommandError("seed_demo only runs with DEBUG on")
        categories = {
            slug: Category.objects.update_or_create(
                slug=slug, defaults={"name_ar": name_ar, "name_en": name_en}
            )[0]
            for slug, name_ar, name_en in CATEGORIES
        }
        stores = [
            Store.objects.update_or_create(
                slug=slug,
                defaults={"name_ar": name_ar, "name_en": name_en, "status": Store.Status.ACTIVE},
            )[0]
            for slug, name_ar, name_en in STORES
        ]
        for index, (category, name_ar, name_en, price) in enumerate(PRODUCTS):
            store = stores[index % len(stores)]
            sku = f"DEMO-{index + 1:03d}"
            if Variant.objects.for_store(store).filter(sku=sku).exists():
                continue
            product = Product.objects.create(
                store=store,
                name_ar=name_ar,
                name_en=name_en,
                category=categories[category],
                status=Product.Status.ACTIVE,
            )
            Variant.objects.create(
                store=store, product=product, sku=sku, price_pt=to_piasters(price)
            )
        self.stdout.write(
            self.style.SUCCESS(f"Seeded {len(stores)} stores, {len(PRODUCTS)} products")
        )
