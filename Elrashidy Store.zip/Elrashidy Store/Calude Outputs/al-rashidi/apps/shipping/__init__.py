"""Courier adapters (Bosta first), webhooks, settlement import.

Traces to: FR-SHP-01 to 04 · T-32 to T-34
"""
