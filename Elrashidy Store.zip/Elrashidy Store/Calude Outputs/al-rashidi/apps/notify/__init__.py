"""SMS and WhatsApp adapters, templates, outbox.

Traces to: FR-NTF-01, FR-NTF-02 · T-16, T-36
"""
