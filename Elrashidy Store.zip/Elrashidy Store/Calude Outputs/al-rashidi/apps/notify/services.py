"""Service layer for notify.

Other apps call these functions and never import this app's models directly
(see docs/conventions.md, rule 1).
"""
