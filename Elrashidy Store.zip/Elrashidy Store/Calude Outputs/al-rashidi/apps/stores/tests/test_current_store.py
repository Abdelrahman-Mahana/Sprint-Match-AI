import pytest
from django.contrib.auth import get_user_model
from django.contrib.auth.models import AnonymousUser

from apps.stores.models import StoreMembership
from apps.stores.services import store_for_user
from tests.factories import make_store

pytestmark = pytest.mark.django_db


def test_staff_user_resolves_to_their_store():
    store = make_store()
    user = get_user_model().objects.create_user("cashier1", password="a-long-password")
    StoreMembership.objects.create(user=user, store=store, role=StoreMembership.Role.CASHIER)
    assert store_for_user(user) == store


def test_customers_and_admins_have_no_store():
    admin = get_user_model().objects.create_superuser("admin", password="a-long-password")
    assert store_for_user(admin) is None
    assert store_for_user(AnonymousUser()) is None
