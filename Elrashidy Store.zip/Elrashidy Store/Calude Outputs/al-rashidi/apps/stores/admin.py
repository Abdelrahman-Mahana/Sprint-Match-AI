from django.contrib import admin

from .models import Store, StoreMembership


@admin.register(Store)
class StoreAdmin(admin.ModelAdmin):
    list_display = ["name_ar", "name_en", "status", "commission_bps"]
    list_filter = ["status"]
    prepopulated_fields = {"slug": ["name_en"]}


@admin.register(StoreMembership)
class StoreMembershipAdmin(admin.ModelAdmin):
    list_display = ["user", "store", "role"]
    list_filter = ["store", "role"]
