from collections.abc import Callable

from django.http import HttpRequest, HttpResponse
from django.utils.functional import SimpleLazyObject

from .services import store_for_user


class CurrentStoreMiddleware:
    """Sets ``request.store`` to the signed-in staff user's store, or ``None``.

    Views pass it to ``Model.objects.for_store(request.store)``. Customers and platform
    admins have no store.
    """

    def __init__(self, get_response: Callable[[HttpRequest], HttpResponse]) -> None:
        self.get_response = get_response

    def __call__(self, request: HttpRequest) -> HttpResponse:
        request.store = SimpleLazyObject(lambda: store_for_user(request.user))  # type: ignore[attr-defined]
        return self.get_response(request)
