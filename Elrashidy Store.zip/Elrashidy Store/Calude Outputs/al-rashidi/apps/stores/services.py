"""Service layer for stores.

Other apps call these functions and never import this app's models directly
(see docs/conventions.md, rule 1).
"""

from typing import TYPE_CHECKING

from .models import Store, StoreMembership

if TYPE_CHECKING:
    from django.contrib.auth.models import AnonymousUser

    from apps.accounts.models import User


# For other apps' read queries that join through a store foreign key.
STORE_ACTIVE = Store.Status.ACTIVE


def store_for_user(user: "User | AnonymousUser") -> Store | None:
    """The store a staff user belongs to. ``None`` for customers and platform admins."""
    if not user.is_authenticated:
        return None
    membership = StoreMembership.objects.select_related("store").filter(user=user).first()
    return membership.store if membership else None
