"""Store, membership, courier account, commission rate.

Traces to: FR-ADM-01, FR-ADM-02 · T-17, T-40
"""
