from django.conf import settings
from django.db import models

from apps.core.models import TimeStampedModel


class Store(TimeStampedModel):
    """An invited shop that sells on the platform. Al-Rashidi is store 1."""

    class Status(models.TextChoices):
        INVITED = "invited", "Invited"
        ACTIVE = "active", "Active"
        SUSPENDED = "suspended", "Suspended"

    name_ar = models.CharField(max_length=120)
    name_en = models.CharField(max_length=120, blank=True)
    slug = models.SlugField(unique=True)
    # Commission in basis points: 1000 = 10% (BR-05). The default rate is still to confirm.
    commission_bps = models.PositiveIntegerField(default=0)
    courier_account_ref = models.CharField(max_length=120, blank=True)
    status = models.CharField(max_length=12, choices=Status, default=Status.INVITED)

    class Meta:
        ordering = ["id"]

    def __str__(self) -> str:
        return self.name_ar


class StoreMembership(TimeStampedModel):
    """Which store a staff user works for, and in what role (SRS: roles and permissions)."""

    class Role(models.TextChoices):
        MANAGER = "manager", "Store manager"
        STAFF = "staff", "Store staff"
        CASHIER = "cashier", "Cashier"
        ACCOUNTANT = "accountant", "Accountant (read)"

    user = models.OneToOneField(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="membership"
    )
    store = models.ForeignKey(Store, on_delete=models.CASCADE, related_name="memberships")
    role = models.CharField(max_length=12, choices=Role)

    def __str__(self) -> str:
        return f"{self.user} · {self.store} · {self.role}"
