"""Money is stored as integer piasters (1 EGP = 100 piasters), never as floats (ADR-004).

Field and variable names that hold money end in ``_pt``.
"""

from decimal import Decimal, InvalidOperation

PIASTERS_PER_EGP = 100
_ARABIC_DIGITS = str.maketrans("٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹٫", "01234567890123456789.")


def to_piasters(amount: str | int | Decimal) -> int:
    """Parse a pound amount typed by a person, in Arabic or Latin digits, into piasters."""
    if isinstance(amount, float):
        raise TypeError("Money never passes through float")
    text = str(amount).translate(_ARABIC_DIGITS).replace(",", "").strip()
    try:
        value = Decimal(text)
    except InvalidOperation as exc:
        raise ValueError(f"Not a money amount: {amount!r}") from exc
    piasters = value * PIASTERS_PER_EGP
    if piasters != piasters.to_integral_value():
        raise ValueError(f"More than two decimal places: {amount!r}")
    return int(piasters)


def format_egp(piasters: int, lang: str = "ar") -> str:
    """Format for display: ``1,250 ج.م`` or ``EGP 1,250.50``. Decimals show only when needed."""
    sign = "-" if piasters < 0 else ""
    pounds, rest = divmod(abs(piasters), PIASTERS_PER_EGP)
    number = f"{pounds:,}" + (f".{rest:02d}" if rest else "")
    if lang.startswith("ar"):
        return f"{sign}{number} ج.م"
    return f"{sign}EGP {number}"


def percent_of(amount_pt: int, basis_points: int) -> int:
    """Share of an amount in basis points (1000 = 10%), rounded half up to the piaster."""
    return (amount_pt * basis_points + 5_000) // 10_000
