"""Shared kernel: money, time, store scoping base classes. No business rules.

Traces to: -
"""
