import pytest

from apps.core.money import format_egp, percent_of, to_piasters


@pytest.mark.parametrize(
    ("typed", "piasters"),
    [("12.50", 1250), ("12", 1200), ("١٢٫٥٠", 1250), ("1,250", 125000), (7, 700)],
)
def test_to_piasters_accepts_arabic_and_latin_digits(typed, piasters):
    assert to_piasters(typed) == piasters


@pytest.mark.parametrize("typed", ["12.505", "abc", ""])
def test_to_piasters_refuses_bad_amounts(typed):
    with pytest.raises(ValueError):
        to_piasters(typed)


def test_money_never_passes_through_float():
    with pytest.raises(TypeError):
        to_piasters(12.5)  # type: ignore[arg-type]


def test_format_egp():
    assert format_egp(125000) == "1,250 ج.م"
    assert format_egp(125050, "en") == "EGP 1,250.50"
    assert format_egp(-500) == "-5 ج.م"


def test_percent_of_rounds_half_up_to_the_piaster():
    assert percent_of(10000, 1000) == 1000  # 10% of 100 EGP
    assert percent_of(333, 1000) == 33  # 33.3 piasters rounds down
    assert percent_of(335, 1000) == 34  # 33.5 piasters rounds up
