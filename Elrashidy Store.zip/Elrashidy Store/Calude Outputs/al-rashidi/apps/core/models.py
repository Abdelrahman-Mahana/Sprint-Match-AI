"""Base classes every store-owned model inherits (TDD: conventions; FR-SEC-02)."""

from typing import TYPE_CHECKING, Self

from django.db import models

if TYPE_CHECKING:
    from apps.stores.models import Store


class StoreScopedQuerySet(models.QuerySet):
    def for_store(self, store: "Store | int") -> Self:
        """The only way views and services read store-owned rows."""
        store_id = store if isinstance(store, int) else store.pk
        return self.filter(store_id=store_id)


class StoreScopedModel(models.Model):
    """A row that belongs to exactly one store.

    Read through ``Model.objects.for_store(request.store)``. A view or API that reads a
    store-owned model any other way fails the isolation test (AT-02).
    """

    store = models.ForeignKey("stores.Store", on_delete=models.PROTECT, related_name="+")

    objects = StoreScopedQuerySet.as_manager()

    class Meta:
        abstract = True


class TimeStampedModel(models.Model):
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        abstract = True
