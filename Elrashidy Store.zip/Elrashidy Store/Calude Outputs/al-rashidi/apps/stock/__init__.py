"""Append-only stock ledger, reservations, counts, purchase receipts.

Traces to: FR-STK-01 to 06 · T-27, T-28
"""
