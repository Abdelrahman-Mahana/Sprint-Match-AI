"""Service layer for audit.

Every state change in the platform goes through a service function that calls ``record``
(see docs/conventions.md, rule 4).
"""

from typing import TYPE_CHECKING, Any

from django.db import models

from .models import AuditLog

if TYPE_CHECKING:
    from apps.accounts.models import User
    from apps.stores.models import Store


def record(
    *,
    action: str,
    obj: models.Model,
    actor: "User | None" = None,
    store: "Store | None" = None,
    old: dict[str, Any] | None = None,
    new: dict[str, Any] | None = None,
    ip: str | None = None,
) -> AuditLog:
    return AuditLog.objects.create(
        actor=actor,
        store=store,
        action=action,
        object_type=obj._meta.label_lower,
        object_id=str(obj.pk),
        old=old,
        new=new,
        ip=ip,
    )
