from typing import Any

from django.conf import settings
from django.db import models


class AppendOnlyError(RuntimeError):
    """Raised when code tries to change or delete an append-only row."""


class AppendOnlyQuerySet(models.QuerySet):
    def update(self, **kwargs: Any) -> int:
        raise AppendOnlyError("Audit rows are never updated")

    def delete(self) -> tuple[int, dict[str, int]]:
        raise AppendOnlyError("Audit rows are never deleted")


class AuditLog(models.Model):
    """Who changed what, when, with the old and new value (NFR-AUD-01). Append-only."""

    actor = models.ForeignKey(
        settings.AUTH_USER_MODEL, null=True, on_delete=models.PROTECT, related_name="+"
    )
    store = models.ForeignKey("stores.Store", null=True, on_delete=models.PROTECT, related_name="+")
    action = models.CharField(max_length=80)
    object_type = models.CharField(max_length=80)
    object_id = models.CharField(max_length=40)
    old = models.JSONField(null=True)
    new = models.JSONField(null=True)
    ip = models.GenericIPAddressField(null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    objects = AppendOnlyQuerySet.as_manager()

    class Meta:
        ordering = ["-created_at", "-id"]
        indexes = [models.Index(fields=["object_type", "object_id"])]

    def __str__(self) -> str:
        return f"{self.action} {self.object_type}#{self.object_id}"

    def save(self, *args: Any, **kwargs: Any) -> None:
        if self.pk is not None:
            raise AppendOnlyError("Audit rows are never updated")
        super().save(*args, **kwargs)

    def delete(self, *args: Any, **kwargs: Any) -> tuple[int, dict[str, int]]:
        raise AppendOnlyError("Audit rows are never deleted")
