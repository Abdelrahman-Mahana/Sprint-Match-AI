import pytest

from apps.audit import services as audit
from apps.audit.models import AppendOnlyError, AuditLog
from tests.factories import make_store

pytestmark = pytest.mark.django_db


def test_record_stores_who_what_old_and_new():
    store = make_store()
    entry = audit.record(
        action="store.commission_changed",
        obj=store,
        store=store,
        old={"commission_bps": 0},
        new={"commission_bps": 1000},
    )
    assert entry.object_type == "stores.store"
    assert entry.object_id == str(store.pk)
    assert entry.new == {"commission_bps": 1000}


def test_audit_rows_are_append_only():
    """NFR-AUD-01: nobody edits or deletes history, through a row or a queryset."""
    store = make_store()
    entry = audit.record(action="store.created", obj=store)
    entry.action = "tampered"
    with pytest.raises(AppendOnlyError):
        entry.save()
    with pytest.raises(AppendOnlyError):
        entry.delete()
    with pytest.raises(AppendOnlyError):
        AuditLog.objects.update(action="tampered")
    with pytest.raises(AppendOnlyError):
        AuditLog.objects.all().delete()
    assert AuditLog.objects.get().action == "store.created"
