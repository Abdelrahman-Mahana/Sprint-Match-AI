"""Append-only audit log of who changed what.

Traces to: NFR-AUD-01 · T-16
"""
