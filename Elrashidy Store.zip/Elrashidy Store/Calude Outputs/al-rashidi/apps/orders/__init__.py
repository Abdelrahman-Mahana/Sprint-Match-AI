"""Cart, order group, per-store order, state machine, coupons.

Traces to: FR-CHK-01 to 07, FR-ORD-01 to 04 · T-22 to T-26
"""
