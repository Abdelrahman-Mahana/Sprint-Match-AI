"""Return request, inspection, refund record.

Traces to: FR-RET-01 to 03 · T-35
"""
